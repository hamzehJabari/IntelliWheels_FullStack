# IntelliWheels - Complete Documentation

---

<div align="center">

# 🚗 IntelliWheels

### **Jordan's AI-Powered Automotive Marketplace**

*Intelligent Car Discovery, Pricing & Listing Platform*

---

</div>

## 📋 Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Platform Overview](#2-platform-overview)
3. [Target Audience](#3-target-audience)
4. [Core Features](#4-core-features)
5. [System Architecture](#5-system-architecture)
6. [User Journey Flowcharts](#6-user-journey-flowcharts)
7. [AI Capabilities](#7-ai-capabilities)
8. [Technical Stack](#8-technical-stack)
9. [Database Schema](#9-database-schema)
10. [API Documentation](#10-api-documentation)
11. [Security Features](#11-security-features)
12. [Internationalization](#12-internationalization)
13. [Deployment Architecture](#13-deployment-architecture)
14. [Business Model](#14-business-model)

---

## 1. Executive Summary

**IntelliWheels** is a modern, AI-powered automotive marketplace designed specifically for the Jordanian market. It combines traditional car listing functionality with cutting-edge artificial intelligence to provide users with smart search, intelligent price estimation, and vision-based vehicle recognition.

### Key Differentiators:
- 🤖 **AI-Powered Natural Language Search** - Find cars by describing what you want
- 📸 **Computer Vision** - Upload a car photo to identify make, model & get price estimates
- 💰 **Smart Price Analysis** - Machine learning-based fair market value estimation
- 🌐 **Bilingual Support** - Full English and Arabic (RTL) interface
- 💱 **Multi-Currency** - JOD, USD, EUR, SAR support with real-time conversion
- ✅ **Verified Dealers** - Trusted dealer network with application/approval workflow

---

## 2. Platform Overview

### 2.1 What IntelliWheels Does

IntelliWheels is a comprehensive automotive platform that serves three main functions:

```
┌─────────────────────────────────────────────────────────────────────┐
│                        INTELLIWHEELS PLATFORM                        │
├─────────────────────┬─────────────────────┬─────────────────────────┤
│    🏪 MARKETPLACE   │   🏢 DEALER HUB     │    🧠 AI INSIGHTS       │
│                     │                     │                         │
│  • Browse listings  │  • Manage inventory │  • AI Chatbot           │
│  • Search cars      │  • Track analytics  │  • Vision recognition   │
│  • Save favorites   │  • Lead management  │  • Price estimation     │
│  • Contact dealers  │  • Listing creation │  • Market analytics     │
│  • User reviews     │  • Performance data │  • Semantic search      │
└─────────────────────┴─────────────────────┴─────────────────────────┘
```

### 2.2 Platform Modes (Workspaces)

Users can switch between three workspace modes:

| Mode | Description | Primary Users |
|------|-------------|---------------|
| **Marketplace** | Browse inventory, search cars, manage favorites | Car Buyers |
| **Dealer Hub** | Manage listings, view analytics, track leads | Car Sellers/Dealers |
| **AI Insights** | Chat with AI, get price analysis, use vision tools | All Users |

---

## 3. Target Audience

### 3.1 Primary User Segments

```
┌────────────────────────────────────────────────────────────────────┐
│                      TARGET AUDIENCE BREAKDOWN                      │
├────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐  │
│  │   CAR BUYERS     │  │   CAR SELLERS    │  │    DEALERS       │  │
│  │   (Individual)   │  │   (Individual)   │  │   (Business)     │  │
│  ├──────────────────┤  ├──────────────────┤  ├──────────────────┤  │
│  │ • First-time     │  │ • Private owners │  │ • Car dealerships│  │
│  │   buyers         │  │   selling cars   │  │ • Auto showrooms │  │
│  │ • Upgrading      │  │ • Fleet managers │  │ • Used car lots  │  │
│  │   existing car   │  │ • Car enthusiasts│  │ • Import agents  │  │
│  │ • Family car     │  │                  │  │                  │  │
│  │   shoppers       │  │                  │  │                  │  │
│  └──────────────────┘  └──────────────────┘  └──────────────────┘  │
│                                                                     │
│  Demographics:                                                      │
│  • Location: Jordan (Amman, Irbid, Zarqa, Aqaba)                   │
│  • Age: 25-55 years                                                 │
│  • Language: Arabic (primary), English (secondary)                  │
│  • Income: Middle to upper-middle class                             │
│                                                                     │
└────────────────────────────────────────────────────────────────────┘
```

### 3.2 User Personas

#### 👤 Persona 1: Ahmad (Car Buyer)
- **Age:** 32, Software Engineer
- **Goal:** Find a reliable family SUV under 25,000 JOD
- **Pain Points:** Doesn't trust used car prices, wants expert validation
- **How IntelliWheels Helps:** AI price estimation, verified dealers, semantic search ("reliable family SUV under 25k")

#### 👤 Persona 2: Sara (Private Seller)
- **Age:** 28, Marketing Manager
- **Goal:** Sell her 2020 Honda Civic quickly at fair price
- **Pain Points:** Doesn't know fair market value, creating listings is tedious
- **How IntelliWheels Helps:** Vision Helper auto-fills listing from photo, AI suggests pricing

#### 👤 Persona 3: Luxury Motors (Dealer)
- **Age:** N/A (Business)
- **Goal:** Manage 50+ inventory items, track performance
- **Pain Points:** Needs analytics, wants verified status for trust
- **How IntelliWheels Helps:** Dealer Hub analytics, verified badge, inventory management

---

## 4. Core Features

### 4.1 Feature Overview Diagram

```
                            ┌─────────────────────────────┐
                            │      INTELLIWHEELS          │
                            │     FEATURE ECOSYSTEM       │
                            └─────────────┬───────────────┘
                                          │
        ┌─────────────────────────────────┼─────────────────────────────────┐
        │                                 │                                 │
        ▼                                 ▼                                 ▼
┌───────────────────┐          ┌───────────────────┐          ┌───────────────────┐
│   CORE FEATURES   │          │   AI FEATURES     │          │  USER FEATURES    │
├───────────────────┤          ├───────────────────┤          ├───────────────────┤
│ • Car Catalog     │          │ • AI Chatbot      │          │ • User Auth       │
│ • Advanced Search │          │ • Vision Helper   │          │ • Favorites       │
│ • Dealer Network  │          │ • Price Estimator │          │ • My Listings     │
│ • Listing CRUD    │          │ • Semantic Search │          │ • Reviews/Ratings │
│ • Media Gallery   │          │ • Listing Assist  │          │ • Profile Mgmt    │
│ • Reviews System  │          │ • Analytics       │          │ • Notifications   │
└───────────────────┘          └───────────────────┘          └───────────────────┘
```

### 4.2 Feature Details

#### 🔍 **Search & Discovery**

| Feature | Description |
|---------|-------------|
| **Keyword Search** | Search by make, model, year |
| **Filter System** | Filter by: make, category, condition, transmission, fuel type |
| **Sort Options** | Price (low/high), year (newest), rating |
| **AI Semantic Search** | Natural language: "luxury hybrid SUV under 50k" |

#### 🤖 **AI-Powered Features**

| Feature | Powered By | Description |
|---------|------------|-------------|
| **AI Chatbot** | Google Gemini 2.5 | Conversational assistant for car queries |
| **Vision Helper** | Google Gemini Vision | Upload photo → get make/model/price |
| **Price Estimator** | ML Model | Fair market value based on specs |
| **Listing Assistant** | Google Gemini | Helps create listings conversationally |
| **Semantic Search** | Keyword + Scoring | Find cars by natural description |

#### 📋 **Listing Management**

| Feature | Description |
|---------|-------------|
| **Create Listing** | Full-featured listing form with AI assistance |
| **Media Gallery** | Up to 6 photos + video support |
| **Edit/Update** | Modify existing listings |
| **My Listings** | Dashboard for seller's inventory |
| **Analytics** | Views, favorites, performance metrics |

#### 👥 **User & Dealer Features**

| Feature | Description |
|---------|-------------|
| **User Registration** | Email/password + Google OAuth |
| **Dealer Applications** | Apply to become verified dealer |
| **Admin Panel** | Review/approve dealer applications |
| **Reviews & Ratings** | 5-star rating system for cars |

---

## 5. System Architecture

### 5.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           INTELLIWHEELS ARCHITECTURE                         │
└─────────────────────────────────────────────────────────────────────────────┘

                              ┌─────────────────┐
                              │     USERS       │
                              │ (Web Browsers)  │
                              └────────┬────────┘
                                       │ HTTPS
                                       ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                              FRONTEND (Vercel)                                │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                         Next.js 15 Application                          │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │
│  │  │  React   │  │ Tailwind │  │  TypeScript │ │ Context  │  │ Dynamic  │  │  │
│  │  │Components│  │   CSS    │  │            │  │   API    │  │  Import  │  │  │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘  └──────────┘  │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────┬───────────────────────────────────────┘
                                       │ REST API (HTTPS)
                                       ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                              BACKEND (Render)                                 │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                         Flask Python Application                        │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │  │
│  │  │ Auth API │  │ Cars API │  │  AI API  │  │Dealers   │  │ Reviews  │  │  │
│  │  │          │  │          │  │          │  │   API    │  │   API    │  │  │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘  └──────────┘  │  │
│  │                                    │                                    │  │
│  │  ┌─────────────────────────────────┴───────────────────────────────┐   │  │
│  │  │                        AI SERVICE LAYER                          │   │  │
│  │  │   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐         │   │  │
│  │  │   │   Gemini    │    │    Price    │    │  Semantic   │         │   │  │
│  │  │   │   2.5 API   │    │    Model    │    │   Search    │         │   │  │
│  │  │   └─────────────┘    └─────────────┘    └─────────────┘         │   │  │
│  │  └─────────────────────────────────────────────────────────────────┘   │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────┬───────────────────────────────────────┘
                                       │
                    ┌──────────────────┼──────────────────┐
                    ▼                  ▼                  ▼
          ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
          │   PostgreSQL    │ │   Cloudinary    │ │  Google Gemini  │
          │   (Database)    │ │ (Image Storage) │ │   (AI Model)    │
          └─────────────────┘ └─────────────────┘ └─────────────────┘
```

### 5.2 Component Interaction Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    COMPONENT INTERACTION FLOW                    │
└─────────────────────────────────────────────────────────────────┘

User Action                 Frontend                    Backend                   External
    │                          │                           │                          │
    │  Click "Search"          │                           │                          │
    ├─────────────────────────►│                           │                          │
    │                          │  GET /api/cars?filters    │                          │
    │                          ├──────────────────────────►│                          │
    │                          │                           │  Query PostgreSQL        │
    │                          │                           ├─────────────────────────►│
    │                          │                           │◄─────────────────────────┤
    │                          │◄──────────────────────────┤                          │
    │  Display Results         │                           │                          │
    │◄─────────────────────────┤                           │                          │
    │                          │                           │                          │
    │  Upload Car Image        │                           │                          │
    ├─────────────────────────►│                           │                          │
    │                          │  POST /api/vision-helper  │                          │
    │                          ├──────────────────────────►│                          │
    │                          │                           │  Analyze with Gemini     │
    │                          │                           ├─────────────────────────►│
    │                          │                           │◄─────────────────────────┤
    │                          │  {make, model, price...}  │                          │
    │                          │◄──────────────────────────┤                          │
    │  Show AI Analysis        │                           │                          │
    │◄─────────────────────────┤                           │                          │
```

---

## 6. User Journey Flowcharts

### 6.1 Car Buyer Journey

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         CAR BUYER USER JOURNEY                           │
└─────────────────────────────────────────────────────────────────────────┘

  ┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
  │  Visit   │     │  Browse  │     │   View   │     │  Contact │
  │  Site    │────►│ Catalog  │────►│ Details  │────►│  Dealer  │
  └──────────┘     └──────────┘     └──────────┘     └──────────┘
       │                │                │                │
       │                │                │                │
       ▼                ▼                ▼                ▼
  ┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
  │  Home    │     │  Apply   │     │  Check   │     │  Finalize│
  │  Page    │     │ Filters  │     │ AI Price │     │   Deal   │
  └──────────┘     └──────────┘     └──────────┘     └──────────┘
                        │                │
                        │                │
                        ▼                ▼
                   ┌──────────┐     ┌──────────┐
                   │   AI     │     │   Save   │
                   │ Search   │     │ Favorite │
                   └──────────┘     └──────────┘

ALTERNATIVE PATH (AI-First):
  ┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
  │   Open   │     │  Ask AI  │     │  Review  │     │  Click   │
  │ Chatbot  │────►│ Question │────►│ Response │────►│ Listing  │
  └──────────┘     └──────────┘     └──────────┘     └──────────┘
       │
       │ "Find me a reliable SUV under 20k JOD"
       ▼
  ┌─────────────────────────────────────────────┐
  │  AI returns ranked recommendations with     │
  │  price analysis and direct links            │
  └─────────────────────────────────────────────┘
```

### 6.2 Car Seller Journey

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         CAR SELLER USER JOURNEY                          │
└─────────────────────────────────────────────────────────────────────────┘

  ┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
  │  Sign    │     │  Choose  │     │  Upload  │     │  Enter   │
  │   Up     │────►│Add List  │────►│  Photos  │────►│ Details  │
  └──────────┘     └──────────┘     └──────────┘     └──────────┘
                                          │                │
                                          │ Optional       │
                                          ▼                ▼
                                    ┌──────────┐     ┌──────────┐
                                    │  Vision  │     │AI Price  │
                                    │  Helper  │     │ Assist   │
                                    └──────────┘     └──────────┘
                                          │                │
                                          │ Auto-fills     │ Suggests
                                          │ make/model     │ fair price
                                          ▼                ▼
                                    ┌──────────────────────────┐
                                    │    Review & Publish      │
                                    │       Listing            │
                                    └────────────┬─────────────┘
                                                 │
                                                 ▼
  ┌──────────┐     ┌──────────┐     ┌──────────────────────────┐
  │  Track   │◄────│  Manage  │◄────│    Listing Live!         │
  │Analytics │     │ Listings │     │    Visible in Catalog    │
  └──────────┘     └──────────┘     └──────────────────────────┘
```

### 6.3 Dealer Application Flow

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      DEALER APPLICATION WORKFLOW                         │
└─────────────────────────────────────────────────────────────────────────┘

      APPLICANT                    SYSTEM                      ADMIN
          │                          │                           │
          │  Submit Application      │                           │
          ├─────────────────────────►│                           │
          │  (name, email, phone,    │                           │
          │   city, description)     │                           │
          │                          │  Store in DB              │
          │                          │  Status: PENDING          │
          │                          │                           │
          │                          │  Send Email Notification  │
          │                          ├──────────────────────────►│
          │                          │                           │
          │  Confirmation Email      │                           │
          │◄─────────────────────────┤                           │
          │                          │                           │
          │                          │        Review Application │
          │                          │◄──────────────────────────┤
          │                          │                           │
          │                          │        ┌─────────────┐    │
          │                          │        │  APPROVE or │    │
          │                          │        │   REJECT    │    │
          │                          │        └──────┬──────┘    │
          │                          │◄──────────────┘           │
          │                          │                           │
          │  ┌─────────────────────────────────────────────────┐ │
          │  │ IF APPROVED:                                    │ │
          │  │  • Create dealer record                         │ │
          │  │  • Grant dealer privileges                      │ │
          │  │  • Send approval email                          │ │
          │  │                                                 │ │
          │  │ IF REJECTED:                                    │ │
          │  │  • Update status to REJECTED                    │ │
          │  │  • Send rejection email with reason             │ │
          │  └─────────────────────────────────────────────────┘ │
          │                          │                           │
          │  Result Notification     │                           │
          │◄─────────────────────────┤                           │
```

---

## 7. AI Capabilities

### 7.1 AI Feature Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         AI CAPABILITIES OVERVIEW                         │
└─────────────────────────────────────────────────────────────────────────┘

                           ┌───────────────────┐
                           │   Google Gemini   │
                           │    2.5 Flash      │
                           └─────────┬─────────┘
                                     │
           ┌─────────────────────────┼─────────────────────────┐
           │                         │                         │
           ▼                         ▼                         ▼
   ┌───────────────┐       ┌───────────────┐       ┌───────────────┐
   │   CHATBOT     │       │ VISION HELPER │       │   LISTING     │
   │               │       │               │       │  ASSISTANT    │
   ├───────────────┤       ├───────────────┤       ├───────────────┤
   │ • Q&A about   │       │ • Image       │       │ • Guided      │
   │   cars        │       │   analysis    │       │   listing     │
   │ • Price       │       │ • Make/model  │       │   creation    │
   │   queries     │       │   detection   │       │ • Auto-fill   │
   │ • Comparisons │       │ • Condition   │       │   from chat   │
   │ • Recommend-  │       │   assessment  │       │ • Price       │
   │   ations      │       │ • Price est.  │       │   suggestion  │
   │ • Arabic/EN   │       │               │       │               │
   └───────────────┘       └───────────────┘       └───────────────┘
```

### 7.2 Chatbot Capabilities

The AI Chatbot is trained as an automotive expert for the Jordanian market:

| Capability | Example Query | AI Response Type |
|------------|---------------|------------------|
| Price Inquiry | "How much is a 2022 Camry worth?" | Price range + market context |
| Comparison | "Compare BMW vs Mercedes C-Class" | Feature comparison table |
| Recommendation | "Best family car under 15k JOD" | Ranked suggestions |
| Listing Help | "I want to sell my 2020 Honda" | Guided listing creation |
| General Q&A | "What's better, automatic or manual?" | Expert explanation |

### 7.3 Vision Helper Flow

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          VISION HELPER FLOW                              │
└─────────────────────────────────────────────────────────────────────────┘

    ┌─────────────┐          ┌─────────────┐          ┌─────────────┐
    │   USER      │          │   SYSTEM    │          │   GEMINI    │
    └──────┬──────┘          └──────┬──────┘          └──────┬──────┘
           │                        │                        │
           │  Upload Car Photo      │                        │
           ├───────────────────────►│                        │
           │                        │  Base64 encode         │
           │                        │  Send to Gemini        │
           │                        ├───────────────────────►│
           │                        │                        │
           │                        │                        │ Analyze:
           │                        │                        │ • Make
           │                        │                        │ • Model
           │                        │                        │ • Year
           │                        │                        │ • Body Style
           │                        │                        │ • Condition
           │                        │                        │ • Price Est.
           │                        │                        │
           │                        │  JSON Response         │
           │                        │◄───────────────────────┤
           │                        │                        │
           │  Display Results       │                        │
           │  + Pre-fill Form       │                        │
           │◄───────────────────────┤                        │

Example Output:
┌────────────────────────────────────┐
│  🚗 Detected: Toyota Camry         │
│  📅 Year: ~2020                    │
│  🚙 Body: Sedan                    │
│  💰 Est. Price: 12,000-15,000 JOD  │
│  📝 Condition: Good, minor wear    │
└────────────────────────────────────┘
```

### 7.4 Price Estimation Algorithm

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      PRICE ESTIMATION ALGORITHM                          │
└─────────────────────────────────────────────────────────────────────────┘

INPUT: Make, Model, Year, Specs
         │
         ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ STEP 1: DETERMINE BASE PRICE BY MAKE CATEGORY                           │
├─────────────────────────────────────────────────────────────────────────┤
│  LUXURY (Mercedes, BMW, Audi, Lexus, Porsche)     → Base: 45,000 JOD    │
│  PREMIUM (Volvo, Infiniti, Genesis, Cadillac)     → Base: 30,000 JOD    │
│  STANDARD (Toyota, Honda, Nissan, Hyundai, Kia)   → Base: 18,000 JOD    │
│  BUDGET (Suzuki, Mitsubishi, Renault, Peugeot)    → Base: 12,000 JOD    │
└─────────────────────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ STEP 2: APPLY DEPRECIATION BY AGE                                        │
├─────────────────────────────────────────────────────────────────────────┤
│  Age ≤ 0 years (new):     +10% premium                                  │
│  Age 1-3 years:           -8% per year                                  │
│  Age 4-7 years:           -5% per year (after initial 24%)              │
│  Age 8+ years:            -3% per year (minimum 30% of base)            │
└─────────────────────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ STEP 3: APPLY SPEC ADJUSTMENTS                                           │
├─────────────────────────────────────────────────────────────────────────┤
│  Horsepower > 300:        +15%                                          │
│  Horsepower 200-300:      +5%                                           │
│  Body: SUV/Crossover:     +10%                                          │
│  Body: Coupe/Convertible: +8%                                           │
└─────────────────────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ STEP 4: CALCULATE PRICE RANGE                                            │
├─────────────────────────────────────────────────────────────────────────┤
│  Variance based on make category:                                        │
│    Luxury: ±35%   Premium: ±30%   Standard: ±25%   Budget: ±20%         │
│                                                                          │
│  OUTPUT: { value: basePrice, low: base*(1-var), high: base*(1+var) }    │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Technical Stack

### 8.1 Technology Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         TECHNOLOGY STACK                                 │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────┐    ┌─────────────────────────┐
│       FRONTEND          │    │        BACKEND          │
├─────────────────────────┤    ├─────────────────────────┤
│ • Next.js 16            │    │ • Python 3.11+          │
│ • React 19.2            │    │ • Flask 3.0             │
│ • TypeScript 5          │    │ • Gunicorn              │
│ • Tailwind CSS 3.4      │    │ • Flask-CORS            │
│ • React Context API     │    │ • Flask-Swagger         │
│ • React Compiler        │    │ • sentence-transformers │
│ • Leaflet Maps          │    │ • scikit-learn          │
└─────────────────────────┘    └─────────────────────────┘

┌─────────────────────────┐    ┌─────────────────────────┐
│      DATABASE           │    │    EXTERNAL SERVICES    │
├─────────────────────────┤    ├─────────────────────────┤
│ • PostgreSQL (Prod)     │    │ • Google Gemini 2.5     │
│ • SQLite (Dev)          │    │ • Cloudinary (Images)   │
│ • JSON fields for specs │    │ • Google OAuth          │
│                         │    │ • SMTP (Emails)         │
└─────────────────────────┘    └─────────────────────────┘

┌─────────────────────────┐    ┌─────────────────────────┐
│      DEPLOYMENT         │    │     DEVELOPMENT         │
├─────────────────────────┤    ├─────────────────────────┤
│ • Vercel (Frontend)     │    │ • ESLint                │
│ • Render (Backend)      │    │ • TypeScript            │
│ • Render PostgreSQL     │    │ • PostCSS               │
│ • Cloudinary CDN        │    │ • dotenv                │
└─────────────────────────┘    └─────────────────────────┘
```

### 8.2 Frontend Components Structure

```
src/
├── app/                          # Next.js App Router
│   ├── layout.tsx                # Root layout
│   ├── page.tsx                  # Home page
│   ├── globals.css               # Global styles
│   ├── cars/[id]/page.tsx        # Car detail page
│   └── dealers/[id]/page.tsx     # Dealer detail page
├── components/
│   ├── AppView.tsx               # Main app shell (5300+ lines)
│   ├── CarDetailView.tsx         # Car detail component
│   ├── DealerDetailView.tsx      # Dealer profile component
│   └── DealerMap.tsx             # Leaflet maps integration
├── context/
│   └── AuthContext.tsx           # Authentication context
├── lib/
│   ├── api.ts                    # API client (40+ functions)
│   ├── config.ts                 # Configuration constants
│   ├── types.ts                  # TypeScript interfaces
│   ├── vehicleDatabase.ts        # Make/model reference data
│   └── catalog.ts                # Catalog utilities
└── types/
    └── google.d.ts               # Google Maps types
```

### 8.3 Backend API Structure

```
backend/
├── app/
│   ├── __init__.py               # Flask app factory
│   ├── db.py                     # Database connection (SQLite/PostgreSQL)
│   ├── security.py               # Auth & validation helpers
│   ├── routes/
│   │   ├── ai.py                 # AI endpoints (chatbot, vision, search)
│   │   ├── auth.py               # Authentication (signup, login, OAuth)
│   │   ├── cars.py               # Car CRUD operations
│   │   ├── dealers.py            # Dealer management & applications
│   │   ├── favorites.py          # User favorites
│   │   ├── listings.py           # User listings management
│   │   ├── messages.py           # Buyer-seller messaging
│   │   ├── reviews.py            # Review system
│   │   └── system.py             # Health checks, stats
│   ├── services/
│   │   └── ai_service.py         # Gemini AI integration (820+ lines)
│   └── static/
│       └── swagger.json          # API documentation
├── models/
│   ├── fair_price_model.joblib   # Trained price prediction model
│   ├── car_embeddings.json       # Pre-computed semantic embeddings
│   └── train_price_model.py      # Model training script
├── data/
│   └── cars.json                 # Sample car data
└── run.py                        # Application entry point
```

---

## 9. Database Schema

### 9.1 Entity Relationship Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                       DATABASE ENTITY RELATIONSHIPS                      │
└─────────────────────────────────────────────────────────────────────────┘

┌──────────────────┐         ┌──────────────────┐         ┌──────────────────┐
│      USERS       │         │      CARS        │         │     DEALERS      │
├──────────────────┤         ├──────────────────┤         ├──────────────────┤
│ id (PK)          │◄───┐    │ id (PK)          │    ┌───►│ id (PK)          │
│ username         │    │    │ make             │    │    │ name             │
│ email            │    │    │ model            │    │    │ location         │
│ password_hash    │    │    │ year             │    │    │ contact_email    │
│ role             │    │    │ price            │    │    │ contact_phone    │
│ is_admin         │    │    │ currency         │    │    │ rating           │
│ created_at       │    │    │ description      │    │    │ created_at       │
└──────────────────┘    │    │ image_url        │    │    └──────────────────┘
         │              │    │ gallery_images   │    │              ▲
         │              │    │ video_url        │    │              │
         │              │    │ specs (JSON)     │    │              │
         │              │    │ owner_id (FK) ───┘    │              │
         │              │    │ dealer_id (FK) ───────┘              │
         │              │    │ created_at       │                   │
         │              │    └──────────────────┘                   │
         │              │              ▲                            │
         │              │              │                            │
         │              │    ┌─────────┴────────┐                   │
         │              │    │                  │                   │
┌────────┴───────┐ ┌────┴────┴─────┐    ┌───────┴──────┐    ┌──────┴───────────┐
│ USER_SESSIONS  │ │   FAVORITES   │    │   REVIEWS    │    │DEALER_APPLICATIONS│
├────────────────┤ ├───────────────┤    ├──────────────┤    ├──────────────────┤
│ token (PK)     │ │ user_id (FK)  │    │ id (PK)      │    │ id (PK)          │
│ user_id (FK)   │ │ car_id (FK)   │    │ car_id (FK)  │    │ name             │
│ expires_at     │ │ created_at    │    │ user_id (FK) │    │ email            │
│ created_at     │ │               │    │ rating       │    │ phone            │
└────────────────┘ └───────────────┘    │ comment      │    │ city             │
                                        │ created_at   │    │ status           │
                                        └──────────────┘    │ admin_notes      │
                                                            │ reviewed_by (FK) │
                                                            │ reviewed_at      │
                                                            │ created_at       │
                                                            └──────────────────┘
```

### 9.2 Key Tables Detail

#### Cars Table
```sql
CREATE TABLE cars (
    id              INTEGER PRIMARY KEY,
    make            TEXT NOT NULL,
    model           TEXT NOT NULL,
    year            INTEGER,
    price           REAL,
    currency        TEXT DEFAULT 'JOD',
    description     TEXT,
    image_url       TEXT,
    video_url       TEXT,
    gallery_images  JSON,       -- Array of image URLs
    media_gallery   JSON,       -- Array of {type, url, label}
    specs           JSON,       -- {bodyStyle, horsepower, engine, ...}
    odometer_km     INTEGER,
    condition       TEXT,       -- 'new', 'used', 'certified'
    transmission    TEXT,       -- 'automatic', 'manual', 'cvt'
    fuel_type       TEXT,       -- 'petrol', 'diesel', 'electric', ...
    category        TEXT,       -- 'car', 'suv', 'truck', ...
    owner_id        INTEGER REFERENCES users(id),
    dealer_id       INTEGER REFERENCES dealers(id),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 10. API Documentation

### 10.1 API Endpoints Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           API ENDPOINTS                                  │
└─────────────────────────────────────────────────────────────────────────┘

BASE URL: /api

AUTHENTICATION
├── POST   /auth/signup              Create new account
├── POST   /auth/login               Sign in
├── POST   /auth/logout              Sign out
├── GET    /auth/me                  Get current user
├── PATCH  /auth/profile             Update profile
├── POST   /auth/google              Google OAuth
└── POST   /auth/password-reset      Request password reset

CARS
├── GET    /cars                     List cars (with filters)
├── GET    /cars/:id                 Get car details
├── POST   /cars                     Create listing
├── PATCH  /cars/:id                 Update listing
├── DELETE /cars/:id                 Delete listing
├── GET    /makes                    Get all makes
├── GET    /models                   Get models for make
└── GET    /engines                  Get engines for make/model

FAVORITES
├── GET    /favorites                Get user's favorites
├── POST   /favorites                Add to favorites
└── DELETE /favorites/:carId         Remove from favorites

DEALERS
├── GET    /dealers                  List all dealers
├── GET    /dealers/:id              Get dealer details
├── POST   /dealers/applications     Submit dealer application
├── GET    /dealers/applications     Admin: List applications
├── PUT    /dealers/applications/:id/approve   Approve application
└── PUT    /dealers/applications/:id/reject    Reject application

REVIEWS
├── GET    /reviews/car/:carId       Get reviews for car
├── POST   /reviews/car/:carId       Add review
└── DELETE /reviews/:id              Delete review

MESSAGES
├── GET    /conversations            Get user's conversations
├── GET    /messages/:conversationId Get messages in conversation
├── POST   /messages                 Send a message
└── GET    /messages/unread          Get unread message count

AI FEATURES
├── POST   /chatbot                  AI chat conversation
├── POST   /vision-helper            Analyze car image
├── POST   /price-estimate           Get price estimate
├── GET    /semantic-search          AI-powered search
├── POST   /listing-assistant        Guided listing creation
└── GET    /analytics/insights       Market analytics

SYSTEM
├── GET    /health                   Health check
├── GET    /stats                    Platform statistics
└── GET    /swagger.json             API documentation
```

### 10.2 Key API Examples

#### Semantic Search
```
GET /api/semantic-search?q=luxury suv under 50k&limit=6

Response:
{
  "success": true,
  "results": [
    {
      "car": {
        "id": 123,
        "make": "BMW",
        "model": "X5",
        "year": 2021,
        "price": 45000,
        "currency": "JOD"
      },
      "similarity": 0.95,
      "score": 85
    }
  ]
}
```

#### Vision Helper
```
POST /api/vision-helper
{
  "image_base64": "data:image/jpeg;base64,/9j/4AAQ..."
}

Response:
{
  "success": true,
  "attributes": {
    "make": "Toyota",
    "model": "Camry",
    "year": 2020,
    "bodyStyle": "Sedan",
    "estimatedPrice": 14000,
    "currency": "JOD",
    "conditionDescription": "Good condition, minor wear on tires",
    "highlights": [
      "Detected: Toyota Camry",
      "Year: 2020",
      "Body: Sedan",
      "Est. price: 14,000 JOD"
    ]
  }
}
```

---

## 11. Security Features

### 11.1 Security Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        SECURITY LAYERS                                   │
└─────────────────────────────────────────────────────────────────────────┘

                    ┌─────────────────────────┐
                    │      USER REQUEST       │
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │      HTTPS/TLS          │  Transport encryption
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │       CORS Policy       │  Origin validation
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │     Rate Limiting       │  5-10 req/min for auth
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │   Input Sanitization    │  XSS, SQL injection
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │   Token Validation      │  Bearer token auth
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │   Role Authorization    │  Admin/User/Guest
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │    Business Logic       │  Resource ownership
                    └─────────────────────────┘
```

### 11.2 Security Measures

| Layer | Implementation |
|-------|----------------|
| **Password Hashing** | PBKDF2:SHA256 with 260,000 iterations |
| **Session Tokens** | Cryptographically secure 32-byte tokens |
| **Token Expiry** | 7-day session lifetime |
| **Rate Limiting** | 5 signups/min, 10 logins/min per IP |
| **Input Validation** | Sanitization, length limits, type checks |
| **CORS** | Whitelist of allowed origins |
| **Security Headers** | X-Content-Type-Options, X-Frame-Options |
| **SQL Injection** | Parameterized queries only |
| **XSS Prevention** | HTML entity encoding |

---

## 12. Internationalization

### 12.1 Language Support

```
┌─────────────────────────────────────────────────────────────────────────┐
│                       LANGUAGE SUPPORT                                   │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────┐    ┌─────────────────────────────┐
│      ENGLISH (en)           │    │      ARABIC (ar)            │
├─────────────────────────────┤    ├─────────────────────────────┤
│ • Default language          │    │ • Full RTL support          │
│ • LTR layout                │    │ • Mirrored UI components    │
│ • Latin characters          │    │ • Arabic number formatting  │
│ • Standard date format      │    │ • Cultural adaptations      │
└─────────────────────────────┘    └─────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                      TRANSLATION COVERAGE                                │
├─────────────────────────────────────────────────────────────────────────┤
│  • Navigation items (10+ items)                                         │
│  • Form labels (30+ fields)                                             │
│  • Error messages (20+ messages)                                        │
│  • AI chatbot responses (bilingual)                                     │
│  • System messages (50+ strings)                                        │
│  • Feature descriptions (30+ strings)                                   │
│                                                                          │
│  Total: 200+ translated strings                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 12.2 Currency Support

| Currency | Code | Symbol | Conversion (to JOD) |
|----------|------|--------|---------------------|
| Jordanian Dinar | JOD | د.أ | 1.00 (base) |
| US Dollar | USD | $ | ~0.71 |
| Euro | EUR | € | ~0.77 |
| Saudi Riyal | SAR | ر.س | ~0.19 |
| UAE Dirham | AED | د.إ | ~0.19 |
| Kuwaiti Dinar | KWD | د.ك | ~2.30 |

---

## 13. Deployment Architecture

### 13.1 Production Infrastructure

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    PRODUCTION DEPLOYMENT                                 │
└─────────────────────────────────────────────────────────────────────────┘

     USERS
       │
       │  DNS: intelliwheels.com
       ▼
┌──────────────────┐
│   Cloudflare     │◄── CDN, DDoS protection, SSL
│   (optional)     │
└────────┬─────────┘
         │
    ┌────┴────┐
    │         │
    ▼         ▼
┌───────────────────┐    ┌───────────────────┐
│      VERCEL       │    │      RENDER       │
│    (Frontend)     │    │     (Backend)     │
├───────────────────┤    ├───────────────────┤
│ • Next.js SSR     │    │ • Flask/Gunicorn  │
│ • Edge Functions  │    │ • Auto-scaling    │
│ • Global CDN      │────│ • Health checks   │
│ • Automatic SSL   │ API│ • Container-based │
│                   │    │                   │
│ ENV:              │    │ ENV:              │
│ NEXT_PUBLIC_      │    │ DATABASE_URL      │
│ API_URL           │    │ GEMINI_API_KEY    │
└───────────────────┘    │ CLOUDINARY_*      │
                         └─────────┬─────────┘
                                   │
              ┌────────────────────┼────────────────────┐
              │                    │                    │
              ▼                    ▼                    ▼
     ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
     │   PostgreSQL    │  │   Cloudinary    │  │  Google Cloud   │
     │   (Render)      │  │   (Images)      │  │  (Gemini AI)    │
     ├─────────────────┤  ├─────────────────┤  ├─────────────────┤
     │ • Managed DB    │  │ • Image CDN     │  │ • Gemini 2.5    │
     │ • Auto backups  │  │ • Transforms    │  │ • Vision API    │
     │ • Connection    │  │ • Video hosting │  │ • NLP           │
     │   pooling       │  │ • Persistence   │  │                 │
     └─────────────────┘  └─────────────────┘  └─────────────────┘
```

### 13.2 Environment Variables

#### Frontend (Vercel)
```
NEXT_PUBLIC_API_URL=https://intelliwheels-api.onrender.com/api
```

#### Backend (Render)
```
DATABASE_URL=postgresql://user:pass@host:5432/db
GEMINI_API_KEY=AIza...
FRONTEND_ORIGIN=https://intelliwheels.vercel.app
SECRET_KEY=<32+ char secure random string>
CLOUDINARY_CLOUD_NAME=...
CLOUDINARY_API_KEY=...
CLOUDINARY_API_SECRET=...
GOOGLE_CLIENT_ID=... (for OAuth)
```

---

## 14. Business Model

### 14.1 Revenue Streams (Potential)

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      POTENTIAL REVENUE MODEL                             │
└─────────────────────────────────────────────────────────────────────────┘

┌───────────────────────┐
│   DEALER SUBSCRIPTIONS│
├───────────────────────┤
│ • Basic: Free         │
│   - 10 listings       │
│   - Standard support  │
│                       │
│ • Pro: 50 JOD/month   │
│   - 50 listings       │
│   - Analytics         │
│   - Priority support  │
│                       │
│ • Enterprise: Custom  │
│   - Unlimited         │
│   - API access        │
│   - Dedicated support │
└───────────────────────┘

┌───────────────────────┐    ┌───────────────────────┐
│   FEATURED LISTINGS   │    │   TRANSACTION FEES    │
├───────────────────────┤    ├───────────────────────┤
│ • Highlight: 5 JOD    │    │ • 0.5% on successful  │
│ • Top spot: 15 JOD    │    │   transactions        │
│ • Homepage: 30 JOD    │    │   (when payment       │
│                       │    │   integration added)  │
└───────────────────────┘    └───────────────────────┘

┌───────────────────────┐
│   VALUE-ADDED SERVICES│
├───────────────────────┤
│ • Vehicle inspection  │
│ • Insurance referrals │
│ • Financing partners  │
│ • Extended warranty   │
└───────────────────────┘
```

### 14.2 Key Metrics to Track

| Metric | Description | Target |
|--------|-------------|--------|
| **MAU** | Monthly Active Users | 10,000+ |
| **Listings** | Total active car listings | 5,000+ |
| **Dealers** | Verified dealer partners | 50+ |
| **AI Queries** | Monthly chatbot/vision uses | 20,000+ |
| **Conversion** | View-to-contact rate | >5% |

---

## Appendix A: Quick Start Guide

### For Developers

```bash
# Clone repository
git clone https://github.com/your-org/intelliwheels-fullstack

# Frontend setup
npm install
npm run dev

# Backend setup (separate terminal)
cd backend
python -m venv .venv
.\.venv\Scripts\activate  # Windows
pip install -r requirements.txt
python run.py
```

### Environment Setup
1. Get a Gemini API key from https://aistudio.google.com/app/apikey
2. Create `backend/.env` with `GEMINI_API_KEY=your_key`
3. Access frontend at http://localhost:3000
4. Access backend at http://localhost:5000

---

## Appendix B: Glossary

| Term | Definition |
|------|------------|
| **JOD** | Jordanian Dinar (primary currency) |
| **Semantic Search** | AI-powered search using natural language |
| **Vision Helper** | AI feature that analyzes car images |
| **Dealer Hub** | Section for verified car dealers |
| **Listing Assistant** | AI chatbot that helps create car listings |
| **RTL** | Right-to-Left (for Arabic language support) |

---

<div align="center">

**IntelliWheels** - *Jordan's Smartest Car Marketplace*

© 2025-2026 IntelliWheels. All rights reserved.

</div>
