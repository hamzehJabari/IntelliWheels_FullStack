"""
IntelliWheels Documentation Generator
=====================================
This script generates a professional Word document (.docx) with embedded diagram images.

Requirements:
    pip install python-docx Pillow matplotlib

Usage:
    python generate_documentation.py
"""

import os
from io import BytesIO

# Check and install required packages
def install_packages():
    import subprocess
    import sys
    packages = ['python-docx', 'Pillow', 'matplotlib']
    for package in packages:
        try:
            __import__(package.replace('-', '_').split('[')[0])
        except ImportError:
            print(f"Installing {package}...")
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', package])

install_packages()

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT
from PIL import Image, ImageDraw, ImageFont
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch
import numpy as np

# Create output directory for images
IMAGES_DIR = os.path.join(os.path.dirname(__file__), 'generated_images')
os.makedirs(IMAGES_DIR, exist_ok=True)

def get_font(size=12, bold=False):
    """Get a font, falling back to default if Arial not available."""
    try:
        if bold:
            return ImageFont.truetype("arialbd.ttf", size)
        return ImageFont.truetype("arial.ttf", size)
    except:
        try:
            return ImageFont.truetype("DejaVuSans.ttf", size)
        except:
            return ImageFont.load_default()


# ============================================================================
#                           DIAGRAM GENERATORS
# ============================================================================

def create_system_architecture_diagram():
    """Create the main system architecture diagram."""
    fig, ax = plt.subplots(1, 1, figsize=(14, 10))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 10)
    ax.axis('off')
    ax.set_title('IntelliWheels System Architecture', fontsize=16, fontweight='bold', pad=20)
    
    # Colors
    colors = {
        'user': '#E3F2FD',
        'frontend': '#BBDEFB',
        'backend': '#90CAF9',
        'database': '#64B5F6',
        'external': '#42A5F5',
        'border': '#1565C0'
    }
    
    # User layer
    user_box = FancyBboxPatch((5.5, 9), 3, 0.8, boxstyle="round,pad=0.05",
                               facecolor=colors['user'], edgecolor=colors['border'], linewidth=2)
    ax.add_patch(user_box)
    ax.text(7, 9.4, '👤 Users (Web Browser)', ha='center', va='center', fontsize=11, fontweight='bold')
    
    # Arrow from user to frontend
    ax.annotate('', xy=(7, 8.2), xytext=(7, 9),
                arrowprops=dict(arrowstyle='->', color=colors['border'], lw=2))
    ax.text(7.3, 8.6, 'HTTPS', fontsize=9)
    
    # Frontend layer
    frontend_box = FancyBboxPatch((1, 6), 12, 2, boxstyle="round,pad=0.05",
                                   facecolor=colors['frontend'], edgecolor=colors['border'], linewidth=2)
    ax.add_patch(frontend_box)
    ax.text(7, 7.7, 'FRONTEND (Vercel) - Next.js 16 / React 19.2 / TypeScript', 
            ha='center', va='center', fontsize=11, fontweight='bold')
    
    # Frontend components
    fe_components = ['React\nComponents', 'Tailwind\nCSS', 'Auth\nContext', 'API\nClient', 'Dynamic\nImports']
    for i, comp in enumerate(fe_components):
        x = 2 + i * 2.2
        box = FancyBboxPatch((x, 6.2), 1.8, 0.9, boxstyle="round,pad=0.03",
                             facecolor='white', edgecolor=colors['border'], linewidth=1)
        ax.add_patch(box)
        ax.text(x + 0.9, 6.65, comp, ha='center', va='center', fontsize=8)
    
    # Arrow from frontend to backend
    ax.annotate('', xy=(7, 4.2), xytext=(7, 6),
                arrowprops=dict(arrowstyle='<->', color=colors['border'], lw=2))
    ax.text(7.5, 5.1, 'REST API', fontsize=9)
    
    # Backend layer
    backend_box = FancyBboxPatch((1, 2), 12, 2, boxstyle="round,pad=0.05",
                                  facecolor=colors['backend'], edgecolor=colors['border'], linewidth=2)
    ax.add_patch(backend_box)
    ax.text(7, 3.7, 'BACKEND (Render) - Flask / Python / Gunicorn', 
            ha='center', va='center', fontsize=11, fontweight='bold')
    
    # Backend components
    be_components = ['Auth\nAPI', 'Cars\nAPI', 'AI\nAPI', 'Dealers\nAPI', 'Reviews\nAPI']
    for i, comp in enumerate(be_components):
        x = 2 + i * 2.2
        box = FancyBboxPatch((x, 2.2), 1.8, 0.9, boxstyle="round,pad=0.03",
                             facecolor='white', edgecolor=colors['border'], linewidth=1)
        ax.add_patch(box)
        ax.text(x + 0.9, 2.65, comp, ha='center', va='center', fontsize=8)
    
    # Database and external services
    services = [
        ('PostgreSQL\nDatabase', 2, 0.3),
        ('Cloudinary\nCDN', 5.5, 0.3),
        ('Google\nGemini AI', 9, 0.3),
        ('SMTP\nEmail', 12, 0.3)
    ]
    
    for name, x, y in services:
        box = FancyBboxPatch((x, y), 2, 1.2, boxstyle="round,pad=0.03",
                             facecolor=colors['database'], edgecolor=colors['border'], linewidth=2)
        ax.add_patch(box)
        ax.text(x + 1, y + 0.6, name, ha='center', va='center', fontsize=9, fontweight='bold', color='white')
        ax.annotate('', xy=(x + 1, 2), xytext=(x + 1, y + 1.2),
                    arrowprops=dict(arrowstyle='->', color=colors['border'], lw=1.5))
    
    plt.tight_layout()
    path = os.path.join(IMAGES_DIR, 'system_architecture.png')
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    return path


def create_user_journey_diagram():
    """Create the car buyer user journey diagram."""
    fig, ax = plt.subplots(1, 1, figsize=(14, 6))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 6)
    ax.axis('off')
    ax.set_title('Car Buyer User Journey', fontsize=16, fontweight='bold', pad=20)
    
    colors = ['#E8F5E9', '#C8E6C9', '#A5D6A7', '#81C784', '#66BB6A', '#4CAF50']
    
    steps = [
        ('1. Visit\nSite', '🏠'),
        ('2. Browse\nCatalog', '📋'),
        ('3. Apply\nFilters', '🔍'),
        ('4. View\nDetails', '🚗'),
        ('5. Get AI\nInsights', '🤖'),
        ('6. Contact\nDealer', '📞')
    ]
    
    for i, (text, emoji) in enumerate(steps):
        x = 1 + i * 2.1
        # Box
        box = FancyBboxPatch((x, 2), 1.8, 2, boxstyle="round,pad=0.1",
                             facecolor=colors[i], edgecolor='#2E7D32', linewidth=2)
        ax.add_patch(box)
        # Emoji
        ax.text(x + 0.9, 3.4, emoji, ha='center', va='center', fontsize=24)
        # Text
        ax.text(x + 0.9, 2.5, text, ha='center', va='center', fontsize=10, fontweight='bold')
        
        # Arrow to next step
        if i < len(steps) - 1:
            ax.annotate('', xy=(x + 2.1, 3), xytext=(x + 1.8, 3),
                        arrowprops=dict(arrowstyle='->', color='#2E7D32', lw=2))
    
    # Add alternative AI path
    ax.text(7, 1.2, 'Alternative: AI-First Path', fontsize=10, fontweight='bold', ha='center',
            style='italic', color='#1565C0')
    ax.text(7, 0.7, '"Find me a reliable SUV under 20k JOD" → AI returns ranked recommendations', 
            fontsize=9, ha='center', color='#1565C0')
    
    plt.tight_layout()
    path = os.path.join(IMAGES_DIR, 'user_journey.png')
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    return path


def create_ai_features_diagram():
    """Create the AI capabilities overview diagram."""
    fig, ax = plt.subplots(1, 1, figsize=(12, 8))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 8)
    ax.axis('off')
    ax.set_title('AI-Powered Features', fontsize=16, fontweight='bold', pad=20)
    
    # Central Gemini box
    gemini_box = FancyBboxPatch((4.5, 6), 3, 1.2, boxstyle="round,pad=0.1",
                                 facecolor='#FFF3E0', edgecolor='#E65100', linewidth=3)
    ax.add_patch(gemini_box)
    ax.text(6, 6.6, '🧠 Google Gemini 2.5', ha='center', va='center', fontsize=12, fontweight='bold')
    
    # AI Features
    features = [
        ('💬 AI Chatbot', '#E3F2FD', 0.5, ['Q&A about cars', 'Price queries', 'Comparisons', 'Recommendations']),
        ('📸 Vision Helper', '#F3E5F5', 4, ['Image analysis', 'Make/model detection', 'Condition assessment', 'Price estimation']),
        ('📝 Listing Assistant', '#E8F5E9', 7.5, ['Guided creation', 'Auto-fill from chat', 'Price suggestions', 'Description help']),
    ]
    
    for name, color, x, items in features:
        # Main box
        box = FancyBboxPatch((x, 1.5), 3.5, 3.5, boxstyle="round,pad=0.1",
                             facecolor=color, edgecolor='#424242', linewidth=2)
        ax.add_patch(box)
        ax.text(x + 1.75, 4.5, name, ha='center', va='center', fontsize=11, fontweight='bold')
        
        # Arrow from Gemini
        ax.annotate('', xy=(x + 1.75, 5), xytext=(6, 6),
                    arrowprops=dict(arrowstyle='->', color='#E65100', lw=2,
                                   connectionstyle='arc3,rad=-0.2'))
        
        # Feature items
        for i, item in enumerate(items):
            ax.text(x + 0.3, 3.8 - i * 0.6, f'• {item}', fontsize=9, va='center')
    
    plt.tight_layout()
    path = os.path.join(IMAGES_DIR, 'ai_features.png')
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    return path


def create_tech_stack_diagram():
    """Create the technology stack diagram."""
    fig, ax = plt.subplots(1, 1, figsize=(12, 8))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 8)
    ax.axis('off')
    ax.set_title('Technology Stack', fontsize=16, fontweight='bold', pad=20)
    
    # Stack layers
    layers = [
        ('FRONTEND', '#BBDEFB', ['Next.js 16', 'React 19.2', 'TypeScript 5', 'Tailwind CSS 3.4']),
        ('BACKEND', '#C8E6C9', ['Python 3.11+', 'Flask 3.0', 'Gunicorn', 'scikit-learn']),
        ('DATABASE', '#FFE0B2', ['PostgreSQL (Prod)', 'SQLite (Dev)', 'JSON fields']),
        ('EXTERNAL', '#F8BBD9', ['Gemini 2.5', 'Cloudinary', 'Google OAuth', 'Leaflet']),
        ('DEPLOYMENT', '#D1C4E9', ['Vercel (FE)', 'Render (BE)', 'Render PostgreSQL']),
    ]
    
    for i, (name, color, items) in enumerate(layers):
        y = 6.5 - i * 1.4
        # Main box
        box = FancyBboxPatch((0.5, y - 0.5), 11, 1.2, boxstyle="round,pad=0.05",
                             facecolor=color, edgecolor='#424242', linewidth=2)
        ax.add_patch(box)
        ax.text(1.5, y + 0.1, name, fontsize=11, fontweight='bold', va='center')
        
        # Items
        for j, item in enumerate(items):
            item_box = FancyBboxPatch((3 + j * 2.1, y - 0.3), 2, 0.8, boxstyle="round,pad=0.02",
                                       facecolor='white', edgecolor='#757575', linewidth=1)
            ax.add_patch(item_box)
            ax.text(4 + j * 2.1, y + 0.1, item, fontsize=9, ha='center', va='center')
    
    plt.tight_layout()
    path = os.path.join(IMAGES_DIR, 'tech_stack.png')
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    return path


def create_database_schema_diagram():
    """Create the database entity relationship diagram."""
    fig, ax = plt.subplots(1, 1, figsize=(14, 10))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 10)
    ax.axis('off')
    ax.set_title('Database Schema (Entity Relationship)', fontsize=16, fontweight='bold', pad=20)
    
    def draw_table(ax, x, y, name, fields, pk_color='#FFEB3B'):
        width, height = 2.8, 0.3 * (len(fields) + 1)
        # Header
        header = FancyBboxPatch((x, y - 0.4), width, 0.5, boxstyle="round,pad=0.02",
                                facecolor='#1565C0', edgecolor='#0D47A1', linewidth=2)
        ax.add_patch(header)
        ax.text(x + width/2, y - 0.15, name, ha='center', va='center', 
                fontsize=10, fontweight='bold', color='white')
        
        # Body
        body = Rectangle((x, y - height), width, height - 0.4,
                         facecolor='white', edgecolor='#0D47A1', linewidth=2)
        ax.add_patch(body)
        
        for i, field in enumerate(fields):
            field_y = y - 0.6 - i * 0.3
            if '(PK)' in field:
                ax.add_patch(Rectangle((x, field_y - 0.15), width, 0.3, facecolor=pk_color, alpha=0.3))
            ax.text(x + 0.1, field_y, field, fontsize=8, va='center')
        
        return y - height
    
    # Users table
    draw_table(ax, 0.5, 9, 'USERS', [
        'id (PK)', 'username', 'email', 'password_hash', 'role', 'is_admin', 'created_at'
    ])
    
    # Cars table
    draw_table(ax, 5.5, 9, 'CARS', [
        'id (PK)', 'make', 'model', 'year', 'price', 'currency',
        'description', 'image_url', 'specs (JSON)', 'owner_id (FK)', 'dealer_id (FK)'
    ])
    
    # Dealers table
    draw_table(ax, 10.5, 9, 'DEALERS', [
        'id (PK)', 'name', 'location', 'contact_email', 'phone', 'rating', 'created_at'
    ])
    
    # User Sessions
    draw_table(ax, 0.5, 4.5, 'USER_SESSIONS', [
        'token (PK)', 'user_id (FK)', 'expires_at', 'created_at'
    ])
    
    # Favorites
    draw_table(ax, 4, 4.5, 'FAVORITES', [
        'user_id (FK)', 'car_id (FK)', 'created_at'
    ])
    
    # Reviews
    draw_table(ax, 7.5, 4.5, 'REVIEWS', [
        'id (PK)', 'car_id (FK)', 'user_id (FK)', 'rating', 'comment', 'created_at'
    ])
    
    # Dealer Applications
    draw_table(ax, 10.5, 4.5, 'DEALER_APPS', [
        'id (PK)', 'name', 'email', 'phone', 'status', 'reviewed_by (FK)'
    ])
    
    # Draw relationships
    # Users -> User Sessions
    ax.annotate('', xy=(1.9, 5.5), xytext=(1.9, 6.3),
                arrowprops=dict(arrowstyle='->', color='#1565C0', lw=1.5))
    
    # Users -> Favorites
    ax.annotate('', xy=(5, 5.5), xytext=(2.5, 6.3),
                arrowprops=dict(arrowstyle='->', color='#1565C0', lw=1.5))
    
    # Cars -> Favorites
    ax.annotate('', xy=(5.5, 5.5), xytext=(6.9, 5.8),
                arrowprops=dict(arrowstyle='->', color='#1565C0', lw=1.5))
    
    # Cars -> Reviews
    ax.annotate('', xy=(8.5, 5.5), xytext=(6.9, 5.8),
                arrowprops=dict(arrowstyle='->', color='#1565C0', lw=1.5))
    
    # Users -> Cars (owner)
    ax.annotate('', xy=(5.5, 6.5), xytext=(3.3, 7.5),
                arrowprops=dict(arrowstyle='->', color='#4CAF50', lw=1.5))
    ax.text(4.2, 7.2, 'owns', fontsize=8, color='#4CAF50')
    
    # Dealers -> Cars
    ax.annotate('', xy=(8.3, 6.5), xytext=(10.5, 7),
                arrowprops=dict(arrowstyle='->', color='#FF9800', lw=1.5))
    ax.text(9.2, 7, 'sells', fontsize=8, color='#FF9800')
    
    plt.tight_layout()
    path = os.path.join(IMAGES_DIR, 'database_schema.png')
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    return path


def create_auth_flow_diagram():
    """Create the authentication flow diagram."""
    fig, ax = plt.subplots(1, 1, figsize=(12, 8))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 8)
    ax.axis('off')
    ax.set_title('User Authentication Flow', fontsize=16, fontweight='bold', pad=20)
    
    # Columns
    columns = [('User', 1.5), ('Frontend', 4.5), ('Backend', 7.5), ('Database', 10.5)]
    for name, x in columns:
        ax.text(x, 7.5, name, ha='center', va='center', fontsize=11, fontweight='bold',
                bbox=dict(boxstyle='round', facecolor='#E3F2FD', edgecolor='#1565C0'))
        ax.plot([x, x], [0.5, 7.2], '--', color='#BDBDBD', lw=1)
    
    # Flow steps
    steps = [
        (1.5, 6.5, 4.5, 6.5, 'Enter credentials'),
        (4.5, 6, 7.5, 6, 'POST /auth/signup'),
        (7.5, 5.5, 10.5, 5.5, 'Check uniqueness'),
        (10.5, 5, 7.5, 5, 'User exists?'),
        (7.5, 4.5, 7.5, 4.5, 'Hash password\n(PBKDF2:SHA256)'),
        (7.5, 4, 10.5, 4, 'INSERT user'),
        (7.5, 3.5, 10.5, 3.5, 'Create session'),
        (10.5, 3, 7.5, 3, 'Return token'),
        (7.5, 2.5, 4.5, 2.5, '{token, user}'),
        (4.5, 2, 1.5, 2, 'Store in localStorage'),
        (1.5, 1.5, 1.5, 1.5, '✓ Logged in!'),
    ]
    
    y_pos = 6.5
    for i, (x1, y1, x2, y2, label) in enumerate(steps):
        if x1 != x2:
            ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                        arrowprops=dict(arrowstyle='->', color='#1565C0', lw=1.5))
            mid_x = (x1 + x2) / 2
            ax.text(mid_x, y1 + 0.15, label, fontsize=8, ha='center', 
                    bbox=dict(boxstyle='round', facecolor='white', edgecolor='#BDBDBD', alpha=0.8))
        else:
            ax.text(x1, y1, label, fontsize=9, ha='center', va='center',
                    bbox=dict(boxstyle='round', facecolor='#E8F5E9', edgecolor='#4CAF50'))
    
    plt.tight_layout()
    path = os.path.join(IMAGES_DIR, 'auth_flow.png')
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    return path


def create_price_algorithm_diagram():
    """Create the price estimation algorithm diagram."""
    fig, ax = plt.subplots(1, 1, figsize=(10, 10))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis('off')
    ax.set_title('Price Estimation Algorithm', fontsize=16, fontweight='bold', pad=20)
    
    # Input
    input_box = FancyBboxPatch((3, 9), 4, 0.8, boxstyle="round,pad=0.1",
                                facecolor='#E3F2FD', edgecolor='#1565C0', linewidth=2)
    ax.add_patch(input_box)
    ax.text(5, 9.4, 'INPUT: Make, Model, Year, Specs', ha='center', va='center', fontsize=10, fontweight='bold')
    
    # Arrow
    ax.annotate('', xy=(5, 8), xytext=(5, 9),
                arrowprops=dict(arrowstyle='->', color='#1565C0', lw=2))
    
    # Step 1: Base price by make
    step1 = FancyBboxPatch((1, 6.2), 8, 1.6, boxstyle="round,pad=0.1",
                            facecolor='#FFF3E0', edgecolor='#E65100', linewidth=2)
    ax.add_patch(step1)
    ax.text(5, 7.5, 'STEP 1: Determine Base Price by Make Category', 
            ha='center', va='center', fontsize=10, fontweight='bold')
    ax.text(2, 7, '• LUXURY (Mercedes, BMW): 45,000 JOD', fontsize=9)
    ax.text(2, 6.6, '• PREMIUM (Volvo, Genesis): 30,000 JOD', fontsize=9)
    ax.text(6, 7, '• STANDARD (Toyota, Honda): 18,000 JOD', fontsize=9)
    ax.text(6, 6.6, '• BUDGET (Suzuki, Renault): 12,000 JOD', fontsize=9)
    
    ax.annotate('', xy=(5, 5.2), xytext=(5, 6.2),
                arrowprops=dict(arrowstyle='->', color='#1565C0', lw=2))
    
    # Step 2: Depreciation
    step2 = FancyBboxPatch((1, 3.8), 8, 1.2, boxstyle="round,pad=0.1",
                            facecolor='#E8F5E9', edgecolor='#4CAF50', linewidth=2)
    ax.add_patch(step2)
    ax.text(5, 4.7, 'STEP 2: Apply Depreciation by Age', 
            ha='center', va='center', fontsize=10, fontweight='bold')
    ax.text(2, 4.2, '• Years 1-3: -8% per year', fontsize=9)
    ax.text(5.5, 4.2, '• Years 4-7: -5% per year', fontsize=9)
    ax.text(2, 3.9, '• Years 8+: -3% per year (min 30%)', fontsize=9)
    
    ax.annotate('', xy=(5, 2.8), xytext=(5, 3.8),
                arrowprops=dict(arrowstyle='->', color='#1565C0', lw=2))
    
    # Step 3: Spec adjustments
    step3 = FancyBboxPatch((1, 1.6), 8, 1, boxstyle="round,pad=0.1",
                            facecolor='#F3E5F5', edgecolor='#7B1FA2', linewidth=2)
    ax.add_patch(step3)
    ax.text(5, 2.3, 'STEP 3: Apply Spec Adjustments', 
            ha='center', va='center', fontsize=10, fontweight='bold')
    ax.text(2, 1.9, '• HP > 300: +15%  • SUV/Crossover: +10%', fontsize=9)
    
    ax.annotate('', xy=(5, 0.6), xytext=(5, 1.6),
                arrowprops=dict(arrowstyle='->', color='#1565C0', lw=2))
    
    # Output
    output_box = FancyBboxPatch((2.5, 0), 5, 0.5, boxstyle="round,pad=0.1",
                                 facecolor='#C8E6C9', edgecolor='#2E7D32', linewidth=2)
    ax.add_patch(output_box)
    ax.text(5, 0.25, 'OUTPUT: { value, low, high }', ha='center', va='center', fontsize=10, fontweight='bold')
    
    plt.tight_layout()
    path = os.path.join(IMAGES_DIR, 'price_algorithm.png')
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    return path


def create_deployment_diagram():
    """Create the deployment architecture diagram."""
    fig, ax = plt.subplots(1, 1, figsize=(12, 8))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 8)
    ax.axis('off')
    ax.set_title('Production Deployment Architecture', fontsize=16, fontweight='bold', pad=20)
    
    # Users at top
    user_box = FancyBboxPatch((4.5, 7), 3, 0.8, boxstyle="round,pad=0.1",
                               facecolor='#E3F2FD', edgecolor='#1565C0', linewidth=2)
    ax.add_patch(user_box)
    ax.text(6, 7.4, '🌐 Users', ha='center', va='center', fontsize=11, fontweight='bold')
    
    # Vercel (Frontend)
    vercel_box = FancyBboxPatch((1, 4.5), 4, 2, boxstyle="round,pad=0.1",
                                 facecolor='#E8EAF6', edgecolor='#3F51B5', linewidth=2)
    ax.add_patch(vercel_box)
    ax.text(3, 6.1, '▲ VERCEL', ha='center', va='center', fontsize=12, fontweight='bold')
    ax.text(3, 5.6, 'Frontend Hosting', ha='center', va='center', fontsize=9)
    ax.text(1.3, 5.1, '• Next.js SSR', fontsize=8)
    ax.text(1.3, 4.8, '• Global CDN', fontsize=8)
    ax.text(3, 5.1, '• Edge Functions', fontsize=8)
    ax.text(3, 4.8, '• Auto SSL', fontsize=8)
    
    # Render (Backend)
    render_box = FancyBboxPatch((7, 4.5), 4, 2, boxstyle="round,pad=0.1",
                                 facecolor='#E8F5E9', edgecolor='#4CAF50', linewidth=2)
    ax.add_patch(render_box)
    ax.text(9, 6.1, '🔷 RENDER', ha='center', va='center', fontsize=12, fontweight='bold')
    ax.text(9, 5.6, 'Backend Hosting', ha='center', va='center', fontsize=9)
    ax.text(7.3, 5.1, '• Flask/Gunicorn', fontsize=8)
    ax.text(7.3, 4.8, '• Auto-scaling', fontsize=8)
    ax.text(9, 5.1, '• Health checks', fontsize=8)
    ax.text(9, 4.8, '• Containers', fontsize=8)
    
    # Arrows from users
    ax.annotate('', xy=(3, 6.5), xytext=(5, 7),
                arrowprops=dict(arrowstyle='->', color='#1565C0', lw=2))
    ax.annotate('', xy=(9, 6.5), xytext=(7, 7),
                arrowprops=dict(arrowstyle='->', color='#1565C0', lw=2))
    
    # API arrow between Vercel and Render
    ax.annotate('', xy=(7, 5.5), xytext=(5, 5.5),
                arrowprops=dict(arrowstyle='<->', color='#FF9800', lw=2))
    ax.text(6, 5.8, 'REST API', fontsize=9, ha='center', fontweight='bold', color='#FF9800')
    
    # External services
    services = [
        ('🗄️ PostgreSQL', 1.5, 1.5, '#FFE0B2', '#FF9800'),
        ('☁️ Cloudinary', 4.5, 1.5, '#E1F5FE', '#0288D1'),
        ('🧠 Gemini AI', 7.5, 1.5, '#FFF3E0', '#E65100'),
        ('📧 SMTP', 10.5, 1.5, '#FCE4EC', '#C2185B'),
    ]
    
    for name, x, y, bg, edge in services:
        box = FancyBboxPatch((x - 1, y - 0.5), 2, 1.2, boxstyle="round,pad=0.1",
                             facecolor=bg, edgecolor=edge, linewidth=2)
        ax.add_patch(box)
        ax.text(x, y + 0.1, name, ha='center', va='center', fontsize=9, fontweight='bold')
        ax.annotate('', xy=(x, 4.5), xytext=(x, y + 0.7),
                    arrowprops=dict(arrowstyle='->', color=edge, lw=1.5))
    
    plt.tight_layout()
    path = os.path.join(IMAGES_DIR, 'deployment.png')
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    return path


def create_feature_overview_diagram():
    """Create the feature overview diagram."""
    fig, ax = plt.subplots(1, 1, figsize=(14, 8))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 8)
    ax.axis('off')
    ax.set_title('IntelliWheels Feature Overview', fontsize=16, fontweight='bold', pad=20)
    
    # Central logo area
    center_box = FancyBboxPatch((5, 3.5), 4, 1.5, boxstyle="round,pad=0.1",
                                 facecolor='#1565C0', edgecolor='#0D47A1', linewidth=3)
    ax.add_patch(center_box)
    ax.text(7, 4.4, '🚗 IntelliWheels', ha='center', va='center', 
            fontsize=14, fontweight='bold', color='white')
    ax.text(7, 3.9, "Jordan's AI-Powered\nAutomotive Marketplace", ha='center', va='center', 
            fontsize=9, color='white')
    
    # Feature categories
    categories = [
        ('🔍 SEARCH', ['Keyword Search', 'AI Semantic Search', 'Advanced Filters'], 0.5, 5.5, '#BBDEFB'),
        ('🤖 AI FEATURES', ['Chatbot', 'Vision Helper', 'Price Estimator'], 0.5, 2, '#C8E6C9'),
        ('📋 LISTINGS', ['Create/Edit', 'Media Gallery', 'Analytics'], 10, 5.5, '#FFE0B2'),
        ('👥 USERS', ['Auth/OAuth', 'Favorites', 'Reviews'], 10, 2, '#F8BBD9'),
    ]
    
    for name, items, x, y, color in categories:
        box = FancyBboxPatch((x, y), 3.2, 2.2, boxstyle="round,pad=0.1",
                             facecolor=color, edgecolor='#424242', linewidth=2)
        ax.add_patch(box)
        ax.text(x + 1.6, y + 1.9, name, ha='center', va='center', fontsize=10, fontweight='bold')
        for i, item in enumerate(items):
            ax.text(x + 0.2, y + 1.4 - i * 0.4, f'• {item}', fontsize=9)
        
        # Arrow to center
        if x < 5:
            ax.annotate('', xy=(5, 4.25), xytext=(x + 3.2, y + 1.1),
                        arrowprops=dict(arrowstyle='->', color='#424242', lw=1.5))
        else:
            ax.annotate('', xy=(9, 4.25), xytext=(x, y + 1.1),
                        arrowprops=dict(arrowstyle='->', color='#424242', lw=1.5))
    
    plt.tight_layout()
    path = os.path.join(IMAGES_DIR, 'feature_overview.png')
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    return path


# ============================================================================
#                           DOCUMENT GENERATOR
# ============================================================================

def create_document():
    """Create the Word document with all content and images."""
    print("Creating Word document...")
    doc = Document()
    
    # Set up styles
    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(11)
    
    # Title
    title = doc.add_heading('IntelliWheels', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    subtitle = doc.add_paragraph("Jordan's AI-Powered Automotive Marketplace")
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.runs[0].font.size = Pt(14)
    subtitle.runs[0].font.italic = True
    
    doc.add_paragraph()
    
    # Generate all diagrams
    print("Generating diagrams...")
    diagrams = {
        'feature_overview': create_feature_overview_diagram(),
        'system_architecture': create_system_architecture_diagram(),
        'user_journey': create_user_journey_diagram(),
        'ai_features': create_ai_features_diagram(),
        'tech_stack': create_tech_stack_diagram(),
        'database_schema': create_database_schema_diagram(),
        'auth_flow': create_auth_flow_diagram(),
        'price_algorithm': create_price_algorithm_diagram(),
        'deployment': create_deployment_diagram(),
    }
    
    # =========================================================================
    # Section 1: Executive Summary
    # =========================================================================
    doc.add_heading('1. Executive Summary', 1)
    doc.add_paragraph(
        "IntelliWheels is a modern, AI-powered automotive marketplace designed specifically for the "
        "Jordanian market. It combines traditional car listing functionality with cutting-edge artificial "
        "intelligence to provide users with smart search, intelligent price estimation, and vision-based "
        "vehicle recognition."
    )
    
    doc.add_heading('Key Differentiators', 2)
    features = [
        "🤖 AI-Powered Natural Language Search - Find cars by describing what you want",
        "📸 Computer Vision - Upload a car photo to identify make, model & get price estimates",
        "💰 Smart Price Analysis - Machine learning-based fair market value estimation",
        "🌐 Bilingual Support - Full English and Arabic (RTL) interface",
        "💱 Multi-Currency - JOD, USD, EUR, SAR support with real-time conversion",
        "✅ Verified Dealers - Trusted dealer network with application/approval workflow"
    ]
    for f in features:
        doc.add_paragraph(f, style='List Bullet')
    
    # Feature Overview Diagram
    doc.add_heading('Platform Overview', 2)
    doc.add_picture(diagrams['feature_overview'], width=Inches(6))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_page_break()
    
    # =========================================================================
    # Section 2: System Architecture
    # =========================================================================
    doc.add_heading('2. System Architecture', 1)
    doc.add_paragraph(
        "IntelliWheels follows a modern full-stack architecture with a clear separation between "
        "the frontend (Next.js/React) and backend (Flask/Python) layers. The system integrates "
        "with multiple external services for AI capabilities, media storage, and authentication."
    )
    
    doc.add_picture(diagrams['system_architecture'], width=Inches(6))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_heading('Architecture Components', 2)
    
    # Frontend
    doc.add_heading('Frontend (Vercel)', 3)
    doc.add_paragraph(
        "The frontend is built with Next.js 15 and React 19, providing server-side rendering, "
        "optimized performance, and a modern developer experience. Key technologies include:"
    )
    fe_items = ["Next.js 15 (App Router)", "React 19 with Hooks", "TypeScript 5", 
                "Tailwind CSS 4", "React Context API for state management"]
    for item in fe_items:
        doc.add_paragraph(item, style='List Bullet')
    
    # Backend
    doc.add_heading('Backend (Render)', 3)
    doc.add_paragraph(
        "The backend is a Flask Python application that handles all API requests, "
        "authentication, and business logic. It integrates with external AI services "
        "and manages the database layer."
    )
    be_items = ["Flask 3.0 with Blueprints", "Python 3.11+", "Gunicorn WSGI server",
                "SQLAlchemy-compatible queries", "Flask-CORS for cross-origin requests"]
    for item in be_items:
        doc.add_paragraph(item, style='List Bullet')
    
    doc.add_page_break()
    
    # =========================================================================
    # Section 3: Target Audience
    # =========================================================================
    doc.add_heading('3. Target Audience', 1)
    
    doc.add_heading('Primary User Segments', 2)
    
    # Create a table for user segments
    table = doc.add_table(rows=4, cols=3)
    table.style = 'Table Grid'
    
    headers = ['Segment', 'Description', 'Key Needs']
    for i, header in enumerate(headers):
        table.rows[0].cells[i].text = header
        table.rows[0].cells[i].paragraphs[0].runs[0].bold = True
    
    segments = [
        ('Car Buyers', 'Individual consumers looking to purchase vehicles', 
         'Easy search, price validation, trusted sellers'),
        ('Car Sellers', 'Private owners wanting to sell their vehicles', 
         'Simple listing creation, fair pricing guidance'),
        ('Dealers', 'Professional car dealerships and showrooms', 
         'Inventory management, analytics, verified status')
    ]
    
    for i, (seg, desc, needs) in enumerate(segments, 1):
        table.rows[i].cells[0].text = seg
        table.rows[i].cells[1].text = desc
        table.rows[i].cells[2].text = needs
    
    doc.add_paragraph()
    
    doc.add_heading('User Journey', 2)
    doc.add_picture(diagrams['user_journey'], width=Inches(6))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_page_break()
    
    # =========================================================================
    # Section 4: AI Features
    # =========================================================================
    doc.add_heading('4. AI-Powered Features', 1)
    doc.add_paragraph(
        "IntelliWheels leverages Google's Gemini 2.5 AI model to provide intelligent features "
        "that set it apart from traditional automotive marketplaces."
    )
    
    doc.add_picture(diagrams['ai_features'], width=Inches(5.5))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_heading('AI Chatbot', 2)
    doc.add_paragraph(
        "The AI Chatbot is a conversational assistant trained as an automotive expert for the "
        "Jordanian market. It can answer questions about cars, provide price estimates, make "
        "recommendations, and even help create listings through natural conversation."
    )
    
    capabilities = [
        "Question & Answer - Answer any car-related query",
        "Price Queries - Estimate fair market values",
        "Comparisons - Compare different makes and models",
        "Recommendations - Suggest cars based on user preferences",
        "Bilingual - Supports both English and Arabic"
    ]
    for cap in capabilities:
        doc.add_paragraph(cap, style='List Bullet')
    
    doc.add_heading('Vision Helper', 2)
    doc.add_paragraph(
        "Upload a photo of any car, and the Vision Helper will analyze it to identify the "
        "make, model, approximate year, body style, condition, and provide a price estimate. "
        "This feature is particularly useful for quickly creating listings or validating seller claims."
    )
    
    doc.add_heading('Price Estimation Algorithm', 2)
    doc.add_picture(diagrams['price_algorithm'], width=Inches(4.5))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_page_break()
    
    # =========================================================================
    # Section 5: Technical Stack
    # =========================================================================
    doc.add_heading('5. Technology Stack', 1)
    doc.add_picture(diagrams['tech_stack'], width=Inches(5.5))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_heading('Frontend Technologies', 2)
    fe_tech = [
        ("Next.js 15", "React framework with App Router, SSR, and optimized builds"),
        ("React 19", "UI library with hooks and concurrent features"),
        ("TypeScript 5", "Static typing for improved code quality"),
        ("Tailwind CSS 4", "Utility-first CSS framework"),
    ]
    for name, desc in fe_tech:
        p = doc.add_paragraph()
        p.add_run(f"{name}: ").bold = True
        p.add_run(desc)
    
    doc.add_heading('Backend Technologies', 2)
    be_tech = [
        ("Python 3.11+", "Core programming language"),
        ("Flask 3.0", "Lightweight web framework"),
        ("Gunicorn", "Production WSGI server"),
        ("PostgreSQL", "Production database (SQLite for development)"),
    ]
    for name, desc in be_tech:
        p = doc.add_paragraph()
        p.add_run(f"{name}: ").bold = True
        p.add_run(desc)
    
    doc.add_heading('External Services', 2)
    ext_services = [
        ("Google Gemini 2.5", "AI model for chatbot, vision, and semantic search"),
        ("Cloudinary", "Cloud storage for images and videos with CDN delivery"),
        ("Google OAuth", "Social authentication"),
        ("SMTP", "Email notifications for password reset and dealer applications"),
    ]
    for name, desc in ext_services:
        p = doc.add_paragraph()
        p.add_run(f"{name}: ").bold = True
        p.add_run(desc)
    
    doc.add_page_break()
    
    # =========================================================================
    # Section 6: Database Schema
    # =========================================================================
    doc.add_heading('6. Database Schema', 1)
    doc.add_paragraph(
        "The application uses a relational database (PostgreSQL in production, SQLite in development) "
        "with the following entity relationships:"
    )
    
    doc.add_picture(diagrams['database_schema'], width=Inches(6))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_heading('Core Tables', 2)
    
    tables_desc = [
        ("Users", "Stores user accounts with credentials, roles, and admin status"),
        ("Cars", "Main listing table with make, model, year, price, and JSON specs"),
        ("Dealers", "Verified dealer profiles with contact information and ratings"),
        ("User Sessions", "JWT-like token sessions with expiration"),
        ("Favorites", "Many-to-many relationship between users and cars"),
        ("Reviews", "User ratings and comments for cars (one per user per car)"),
        ("Dealer Applications", "Workflow for dealer verification with status tracking"),
    ]
    
    for name, desc in tables_desc:
        p = doc.add_paragraph()
        p.add_run(f"{name}: ").bold = True
        p.add_run(desc)
    
    doc.add_page_break()
    
    # =========================================================================
    # Section 7: Authentication
    # =========================================================================
    doc.add_heading('7. Authentication & Security', 1)
    
    doc.add_heading('Authentication Flow', 2)
    doc.add_picture(diagrams['auth_flow'], width=Inches(5.5))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_heading('Security Measures', 2)
    
    security_table = doc.add_table(rows=9, cols=2)
    security_table.style = 'Table Grid'
    
    security_items = [
        ('Layer', 'Implementation'),
        ('Password Hashing', 'PBKDF2:SHA256 with 260,000 iterations'),
        ('Session Tokens', 'Cryptographically secure 32-byte tokens'),
        ('Token Expiry', '7-day session lifetime'),
        ('Rate Limiting', '5 signups/min, 10 logins/min per IP'),
        ('Input Validation', 'Sanitization, length limits, type checks'),
        ('CORS', 'Whitelist of allowed origins'),
        ('SQL Injection', 'Parameterized queries only'),
    ]
    
    for i, (key, val) in enumerate(security_items):
        security_table.rows[i].cells[0].text = key
        security_table.rows[i].cells[1].text = val
        if i == 0:
            security_table.rows[i].cells[0].paragraphs[0].runs[0].bold = True
            security_table.rows[i].cells[1].paragraphs[0].runs[0].bold = True
    
    doc.add_page_break()
    
    # =========================================================================
    # Section 8: API Documentation
    # =========================================================================
    doc.add_heading('8. API Documentation', 1)
    doc.add_paragraph("The backend exposes a RESTful API with the following endpoint groups:")
    
    # API Endpoints Table
    api_table = doc.add_table(rows=9, cols=3)
    api_table.style = 'Table Grid'
    
    api_endpoints = [
        ('Category', 'Endpoints', 'Description'),
        ('Authentication', '/auth/*', 'Signup, login, logout, OAuth, password reset'),
        ('Cars', '/cars/*', 'CRUD operations for car listings'),
        ('Favorites', '/favorites/*', 'User favorites management'),
        ('Dealers', '/dealers/*', 'Dealer profiles and applications'),
        ('Reviews', '/reviews/*', 'Car ratings and comments'),
        ('AI Features', '/chatbot, /vision-helper, /semantic-search', 'AI-powered endpoints'),
        ('System', '/health, /stats', 'Health checks and platform statistics'),
    ]
    
    for i, row_data in enumerate(api_endpoints):
        for j, cell_text in enumerate(row_data):
            api_table.rows[i].cells[j].text = cell_text
            if i == 0:
                api_table.rows[i].cells[j].paragraphs[0].runs[0].bold = True
    
    doc.add_paragraph()
    
    doc.add_heading('Example: Semantic Search', 2)
    doc.add_paragraph("Request:", style='Intense Quote')
    doc.add_paragraph("GET /api/semantic-search?q=luxury suv under 50k&limit=6")
    doc.add_paragraph("Response:", style='Intense Quote')
    code = '''
{
  "success": true,
  "results": [
    {
      "car": {"id": 123, "make": "BMW", "model": "X5", "price": 45000},
      "similarity": 0.95
    }
  ]
}'''
    doc.add_paragraph(code)
    
    doc.add_page_break()
    
    # =========================================================================
    # Section 9: Deployment
    # =========================================================================
    doc.add_heading('9. Deployment Architecture', 1)
    doc.add_picture(diagrams['deployment'], width=Inches(5.5))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_heading('Environment Variables', 2)
    
    doc.add_heading('Frontend (Vercel)', 3)
    env_table1 = doc.add_table(rows=2, cols=2)
    env_table1.style = 'Table Grid'
    env_table1.rows[0].cells[0].text = 'Variable'
    env_table1.rows[0].cells[1].text = 'Description'
    env_table1.rows[0].cells[0].paragraphs[0].runs[0].bold = True
    env_table1.rows[0].cells[1].paragraphs[0].runs[0].bold = True
    env_table1.rows[1].cells[0].text = 'NEXT_PUBLIC_API_URL'
    env_table1.rows[1].cells[1].text = 'Backend API URL (e.g., https://intelliwheels.onrender.com/api)'
    
    doc.add_paragraph()
    
    doc.add_heading('Backend (Render)', 3)
    env_table2 = doc.add_table(rows=7, cols=2)
    env_table2.style = 'Table Grid'
    
    backend_env = [
        ('Variable', 'Description'),
        ('DATABASE_URL', 'PostgreSQL connection string'),
        ('GEMINI_API_KEY', 'Google Gemini API key'),
        ('FRONTEND_ORIGIN', 'Frontend URL for CORS'),
        ('SECRET_KEY', 'Session encryption key (32+ chars)'),
        ('CLOUDINARY_*', 'Cloudinary credentials for media storage'),
    ]
    
    for i, (var, desc) in enumerate(backend_env):
        env_table2.rows[i].cells[0].text = var
        env_table2.rows[i].cells[1].text = desc
        if i == 0:
            env_table2.rows[i].cells[0].paragraphs[0].runs[0].bold = True
            env_table2.rows[i].cells[1].paragraphs[0].runs[0].bold = True
    
    doc.add_page_break()
    
    # =========================================================================
    # Section 10: Internationalization
    # =========================================================================
    doc.add_heading('10. Internationalization', 1)
    
    doc.add_heading('Language Support', 2)
    doc.add_paragraph(
        "IntelliWheels provides full support for both English and Arabic, including "
        "right-to-left (RTL) layout for Arabic users."
    )
    
    lang_table = doc.add_table(rows=3, cols=3)
    lang_table.style = 'Table Grid'
    
    lang_data = [
        ('Language', 'Code', 'Features'),
        ('English', 'en', 'Default, LTR layout'),
        ('Arabic', 'ar', 'Full RTL support, mirrored UI'),
    ]
    
    for i, row_data in enumerate(lang_data):
        for j, cell_text in enumerate(row_data):
            lang_table.rows[i].cells[j].text = cell_text
            if i == 0:
                lang_table.rows[i].cells[j].paragraphs[0].runs[0].bold = True
    
    doc.add_paragraph()
    
    doc.add_heading('Currency Support', 2)
    
    currency_table = doc.add_table(rows=7, cols=3)
    currency_table.style = 'Table Grid'
    
    currencies = [
        ('Currency', 'Code', 'Symbol'),
        ('Jordanian Dinar', 'JOD', 'د.أ'),
        ('US Dollar', 'USD', '$'),
        ('Euro', 'EUR', '€'),
        ('Saudi Riyal', 'SAR', 'ر.س'),
        ('UAE Dirham', 'AED', 'د.إ'),
    ]
    
    for i, row_data in enumerate(currencies):
        for j, cell_text in enumerate(row_data):
            currency_table.rows[i].cells[j].text = cell_text
            if i == 0:
                currency_table.rows[i].cells[j].paragraphs[0].runs[0].bold = True
    
    # =========================================================================
    # Final section
    # =========================================================================
    doc.add_page_break()
    doc.add_heading('11. Quick Start Guide', 1)
    
    doc.add_heading('For Developers', 2)
    
    doc.add_heading('Prerequisites', 3)
    doc.add_paragraph('• Node.js 18+')
    doc.add_paragraph('• Python 3.11+')
    doc.add_paragraph('• npm or yarn')
    
    doc.add_heading('Frontend Setup', 3)
    doc.add_paragraph('npm install')
    doc.add_paragraph('npm run dev')
    doc.add_paragraph('# Open http://localhost:3000')
    
    doc.add_heading('Backend Setup', 3)
    doc.add_paragraph('cd backend')
    doc.add_paragraph('python -m venv .venv')
    doc.add_paragraph('.venv\\Scripts\\activate  # Windows')
    doc.add_paragraph('# source .venv/bin/activate  # Mac/Linux')
    doc.add_paragraph('pip install -r requirements.txt')
    doc.add_paragraph('python run.py')
    doc.add_paragraph('# API runs on http://localhost:5000')
    
    doc.add_heading('Environment Setup', 3)
    doc.add_paragraph(
        "1. Get a Gemini API key from https://aistudio.google.com/app/apikey\n"
        "2. Create backend/.env with:\n"
        "   GEMINI_API_KEY=your_key\n"
        "   FRONTEND_ORIGIN=http://localhost:3000\n"
        "3. Access frontend at http://localhost:3000\n"
        "4. Access backend API at http://localhost:5000/api"
    )
    
    # Footer
    doc.add_paragraph()
    doc.add_paragraph()
    footer = doc.add_paragraph("© 2025-2026 IntelliWheels. All rights reserved.")
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.runs[0].font.italic = True
    footer.runs[0].font.size = Pt(10)
    
    # Save document
    doc_path = os.path.join(os.path.dirname(__file__), 'IntelliWheels_Documentation.docx')
    doc.save(doc_path)
    print(f"\n✅ Document saved to: {doc_path}")
    
    return doc_path


if __name__ == '__main__':
    print("=" * 60)
    print("IntelliWheels Documentation Generator")
    print("=" * 60)
    
    doc_path = create_document()
    
    print("\n" + "=" * 60)
    print("Generation Complete!")
    print("=" * 60)
    print(f"\n📄 Word Document: {doc_path}")
    print(f"📁 Generated Images: {IMAGES_DIR}")
    print("\nTo convert to PDF, open the .docx file in Microsoft Word")
    print("and use File > Save As > PDF")
