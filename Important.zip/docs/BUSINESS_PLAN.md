# IntelliWheels Business Plan

**AI-Powered Automotive Marketplace for Jordan & GCC**

**Version:** 1.0  
**Date:** January 2026  
**Confidential**

---

## Executive Summary

### Company Overview
IntelliWheels is an AI-powered automotive marketplace designed specifically for the Jordanian and GCC markets. We leverage cutting-edge artificial intelligence to transform the car buying and selling experience.

### Mission
To make buying and selling cars in Jordan simple, transparent, and trustworthy through AI-powered tools.

### Vision
To become the leading automotive marketplace in the Middle East, known for innovation, trust, and user experience.

### The Opportunity
- Jordan's used car market: Estimated at 500M+ JOD annually
- No dominant digital-first platform with AI capabilities
- Growing smartphone and internet penetration (95%+)
- Young, tech-savvy population seeking modern solutions

### The Solution
- AI chatbot for instant assistance (Arabic/English)
- Vision-based vehicle analysis from photos
- Fair price estimation using ML models
- Verified dealer network with transparency
- Semantic search for natural language queries

### Financial Highlights
| Metric | Year 1 | Year 2 | Year 3 |
|--------|--------|--------|--------|
| Dealers | 100 | 500 | 1,500 |
| Listings | 2,000 | 15,000 | 50,000 |
| Revenue (JOD) | 50,000 | 350,000 | 1,200,000 |
| Status | Investment | Growth | Profitable |

### Funding Request
Seeking **100,000 - 250,000 JOD** seed funding for:
- Team expansion
- Marketing launch
- Feature development
- 18-month runway

---

## 1. Company Description

### 1.1 Business Information
- **Company Name:** IntelliWheels [To be registered]
- **Legal Structure:** Limited Liability Company (LLC)
- **Location:** Amman, Jordan
- **Industry:** Automotive / Technology / E-commerce
- **Stage:** Pre-launch / MVP Ready

### 1.2 Problem Statement

**For Car Buyers:**
- Overwhelming search through fragmented listings
- Difficulty assessing fair prices
- Trust issues with sellers
- Language barriers (Arabic/English)
- No intelligent assistance

**For Car Sellers/Dealers:**
- Limited online presence
- No tools for modern engagement
- Difficulty reaching qualified buyers
- No analytics or insights

### 1.3 Our Solution

| Feature | Problem Solved |
|---------|----------------|
| AI Chatbot | Instant 24/7 assistance |
| Vision Analysis | Easy vehicle assessment |
| Price Estimator | Fair pricing transparency |
| Dealer Verification | Trust and credibility |
| Bilingual Support | Language accessibility |
| Semantic Search | Find cars naturally |

### 1.4 Unique Value Proposition
"The only automotive marketplace in Jordan with AI-powered assistance, making car buying as easy as chatting with an expert friend."

---

## 2. Market Analysis

### 2.1 Market Size (Jordan)

| Segment | Estimated Value |
|---------|-----------------|
| Total Automotive Market | 2+ Billion JOD/year |
| Used Car Market | 500-800M JOD/year |
| Digital Car Listings | 50-100M JOD (potential) |
| Our Target (Year 3) | 10-20M JOD GMV |

### 2.2 Market Trends

**Positive Trends:**
- 📈 Increasing digital adoption post-COVID
- 📈 Smartphone penetration >95%
- 📈 Young population (65% under 35)
- 📈 Growing e-commerce trust
- 📈 AI acceptance rising

**Challenges:**
- 📉 Economic uncertainty
- 📉 Traditional buyer habits
- 📉 Cash-dominant transactions
- 📉 Existing platforms have inertia

### 2.3 Target Audience

**Primary: Car Buyers**
- Age: 25-45
- Income: Middle to upper-middle class
- Tech-savvy, smartphone users
- Value convenience and transparency

**Secondary: Car Dealers**
- Small to medium dealerships
- Looking for digital presence
- Want qualified leads
- Need modern tools

**Tertiary: Individual Sellers**
- Private car owners
- Want quick, fair sales
- First-time sellers need guidance

### 2.4 Competitor Analysis

| Competitor | Strengths | Weaknesses | Our Advantage |
|------------|-----------|------------|---------------|
| OpenSooq | Large user base, established | No AI, cluttered UI | AI features, UX |
| Facebook Marketplace | High traffic | No specialization | Automotive focus |
| Local classifieds | Known brands | Outdated technology | Modern tech stack |
| CarSwitch (UAE) | Funded, good UX | Limited in Jordan | Local focus |

### 2.5 Competitive Advantages

1. **First-mover in AI:** No local competitor offers AI chatbot/vision
2. **Bilingual Excellence:** True Arabic/English with RTL support
3. **Modern Technology:** Next.js, React 19, latest stack
4. **Local Focus:** Built for Jordan's specific needs
5. **Dealer-Friendly:** Tools designed for local dealers

---

## 3. Products and Services

### 3.1 Core Features (MVP - Ready)

| Feature | Description | Status |
|---------|-------------|--------|
| Listing Marketplace | Browse, search, filter cars | ✅ Complete |
| AI Chatbot | Natural language car assistance (Gemini 2.5) | ✅ Complete |
| Vision Analysis | Upload photo for car details | ✅ Complete |
| Price Estimator | ML-based fair price | ✅ Complete |
| Dealer Profiles | Verified dealer pages with map | ✅ Complete |
| User Authentication | Secure login with Google OAuth | ✅ Complete |
| Favorites | Save and track listings | ✅ Complete |
| Semantic Search | Natural language search | ✅ Complete |
| Messaging | Buyer-seller direct communication | ✅ Complete |
| Reviews | Car rating and review system | ✅ Complete |
| Analytics | Dealer performance dashboard | ✅ Complete |

### 3.2 Planned Features (Phase 2)

| Feature | Timeline | Priority |
|---------|----------|----------|
| Payment Integration | Month 2-3 | High |
| Dealer Dashboard Pro | Month 3-4 | High |
| Mobile App | Month 4-6 | Medium |
| Vehicle History Reports | Month 5-7 | Medium |
| Financing Integration | Month 6-8 | Medium |
| Insurance Partnerships | Month 7-9 | Low |

### 3.3 Revenue Streams

| Stream | Model | Estimated Revenue |
|--------|-------|-------------------|
| **Dealer Subscriptions** | 50-200 JOD/month | 60% of revenue |
| **Featured Listings** | 5-30 JOD per listing | 25% of revenue |
| **Premium AI Features** | 5-20 JOD/month | 10% of revenue |
| **Lead Generation** | Per qualified lead | 5% of revenue |

---

## 4. Marketing Strategy

### 4.1 Go-to-Market Strategy

**Phase 1: Soft Launch (Month 1-2)**
- Onboard 20-50 dealers manually
- Gather feedback, iterate
- Build case studies

**Phase 2: Beta Launch (Month 3-4)**
- Expand to 100 dealers
- Begin digital marketing
- PR and media outreach

**Phase 3: Public Launch (Month 5-6)**
- Full marketing campaign
- Influencer partnerships
- Paid advertising

### 4.2 Marketing Channels

| Channel | Budget % | Strategy |
|---------|----------|----------|
| **Social Media** | 30% | Facebook, Instagram, TikTok |
| **Google Ads** | 25% | Search and display |
| **Content Marketing** | 15% | Blog, YouTube, SEO |
| **Influencers** | 15% | Car reviewers, tech influencers |
| **Partnerships** | 10% | Banks, insurance, auto shows |
| **PR** | 5% | Media coverage, events |

### 4.3 Customer Acquisition Cost (CAC)

| User Type | Target CAC | Method |
|-----------|------------|--------|
| Buyer | 2-5 JOD | Digital ads, organic |
| Seller | 5-10 JOD | Referrals, content |
| Dealer | 50-100 JOD | Direct sales, partnerships |

### 4.4 Brand Positioning
- **Tagline:** "Your AI Car Expert" / "خبير السيارات الذكي"
- **Tone:** Helpful, modern, trustworthy
- **Colors:** Blue (#3B82F6) for trust, Orange for energy
- **Personality:** Smart friend who knows cars

---

## 5. Operations Plan

### 5.1 Team Structure (Current)

| Role | Person | Status |
|------|--------|--------|
| Founder/CEO | [Your Name] | Active |
| Full-Stack Developer | [Your Name] | Active |
| (Additional roles) | TBD | Hiring |

### 5.2 Team Structure (Target - 12 months)

```
CEO/Founder
├── CTO/Lead Developer (hire)
│   └── Junior Developer (hire)
├── Operations Manager (hire)
│   ├── Customer Support (2)
│   └── Content Moderator (1)
├── Marketing Manager (hire)
│   └── Social Media (1)
└── Sales (Dealer Relations) (hire)
    └── Sales Rep (1)
```

### 5.3 Key Partnerships

| Partner Type | Examples | Purpose |
|--------------|----------|---------|
| Cloud Services | Vercel, Render, Cloudinary | Infrastructure |
| AI Provider | Google (Gemini) | AI capabilities |
| Payment | Mamo Pay, PayTabs | Transactions |
| Insurance | Local providers | Lead generation |
| Banks | Arab Bank, Housing Bank | Financing leads |
| Media | Roya, Ro'ya | PR and promotion |

### 5.4 Operational Metrics

| Metric | Target (Year 1) |
|--------|-----------------|
| Platform Uptime | 99.5% |
| Support Response | < 24 hours |
| Dealer Onboarding | < 48 hours |
| Listing Approval | < 4 hours |
| User Satisfaction | > 4.0/5.0 |

---

## 6. Financial Plan

### 6.1 Startup Costs

| Category | Amount (JOD) |
|----------|--------------|
| Legal & Registration | 2,000 |
| Initial Marketing | 5,000 |
| Equipment & Software | 2,000 |
| Security Audit | 1,500 |
| Working Capital | 10,000 |
| Buffer | 4,500 |
| **Total** | **25,000** |

### 6.2 Monthly Operating Costs

| Category | Month 1-6 | Month 7-12 |
|----------|-----------|------------|
| Hosting & Infrastructure | 200 | 500 |
| AI API Costs | 100 | 400 |
| Marketing | 1,000 | 3,000 |
| Salaries (founder only) | 1,500 | 1,500 |
| Support Staff | 0 | 800 |
| Tools & Software | 200 | 400 |
| Office/Misc | 500 | 1,000 |
| **Total** | **3,500** | **7,600** |

### 6.3 Revenue Projections

| Revenue Stream | Year 1 | Year 2 | Year 3 |
|----------------|--------|--------|--------|
| Dealer Subscriptions | 30,000 | 200,000 | 700,000 |
| Featured Listings | 15,000 | 100,000 | 350,000 |
| Premium Features | 5,000 | 50,000 | 150,000 |
| **Total Revenue** | **50,000** | **350,000** | **1,200,000** |

### 6.4 Profitability Timeline

| Year | Revenue | Expenses | Net | Status |
|------|---------|----------|-----|--------|
| Year 1 | 50,000 | 80,000 | -30,000 | Investment |
| Year 2 | 350,000 | 300,000 | +50,000 | Break-even |
| Year 3 | 1,200,000 | 800,000 | +400,000 | Profitable |

### 6.5 Funding Requirements

**Seed Round: 100,000 - 250,000 JOD**

| Use of Funds | Amount | % |
|--------------|--------|---|
| Team (salaries) | 100,000 | 40% |
| Marketing | 75,000 | 30% |
| Product Development | 50,000 | 20% |
| Operations & Legal | 25,000 | 10% |

**Milestones for Investment:**
- Month 6: 100 paying dealers
- Month 12: 500 dealers, break-even path
- Month 18: Profitability or Series A ready

---

## 7. Risk Analysis

### 7.1 Risks and Mitigation

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Competition enters | High | Medium | First-mover advantage, feature moat |
| Low dealer adoption | Medium | High | Direct sales, incentives, case studies |
| Economic downturn | Medium | Medium | Diversify revenue, lean operations |
| Technical failures | Low | High | Monitoring, backups, redundancy |
| Regulatory changes | Low | Medium | Legal compliance, stay informed |
| AI accuracy issues | Medium | Medium | Disclaimers, continuous improvement |
| Key person risk | High | High | Document everything, hire team |

### 7.2 Contingency Plans

**If dealer adoption is slow:**
- Pivot to individual sellers first
- Offer free trials longer
- Partner with dealer associations

**If funding not secured:**
- Bootstrap with minimal team
- Focus on revenue-generating features
- Consider consulting/services revenue

---

## 8. Milestones and Timeline

### 8.1 Key Milestones

| Milestone | Target Date | Status |
|-----------|-------------|--------|
| MVP Complete | ✅ Done | Complete |
| Legal Document Templates | ✅ Done | Complete |
| Production Deployment | ✅ Done | Complete |
| Company Registration | Month 1 | Pending |
| Security Audit | Month 2 | Pending |
| Soft Launch (20 dealers) | Month 2 | Pending |
| Payment Integration | Month 3 | Pending |
| Beta Launch (100 dealers) | Month 4 | Pending |
| Seed Funding Close | Month 4-5 | Pending |
| Public Launch | Month 6 | Pending |
| 500 Dealers | Month 12 | Target |
| Break-even | Month 18 | Target |
| Series A Ready | Month 24 | Target |

### 8.2 90-Day Action Plan

**Month 1:**
- [ ] Register company
- [ ] Complete legal documents
- [ ] Set up bank account
- [ ] Domain and email setup
- [ ] Begin dealer outreach

**Month 2:**
- [ ] Security audit
- [ ] Payment integration
- [ ] Onboard first 20 dealers
- [ ] Launch support system
- [ ] Begin marketing content

**Month 3:**
- [ ] Expand to 50 dealers
- [ ] Launch social media
- [ ] PR outreach
- [ ] Iterate based on feedback
- [ ] Prepare investor materials

---

## 9. Appendix

### 9.1 Technical Specifications
See [FULL_DOCUMENTATION.md](./FULL_DOCUMENTATION.md)

### 9.2 Visual Architecture
See [VISUAL_DIAGRAMS.md](./VISUAL_DIAGRAMS.md)

### 9.3 Legal Documents
- Terms of Service
- Privacy Policy
- Dealer Agreement

### 9.4 Team Backgrounds
[Add founder bios and relevant experience]

### 9.5 Market Research Data
[Add supporting market data and sources]

---

## Contact

**IntelliWheels**  
[Founder Name]  
Email: [email]  
Phone: [phone]  
Location: Amman, Jordan

---

*This business plan is confidential and intended for potential investors and partners only.*

*Last Updated: January 2026*
