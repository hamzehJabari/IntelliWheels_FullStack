# IntelliWheels Business Readiness Checklist

## 🚀 From Code to Company: What You Still Need

This document outlines everything required to transform IntelliWheels from a codebase into a fully operational, legally compliant business in Jordan.

---

## Table of Contents

1. [Legal & Government Registration](#1-legal--government-registration-jordan)
2. [Legal Documents & Policies](#2-legal-documents--policies)
3. [Production Readiness](#3-production-readiness-technical)
4. [Financial Infrastructure](#4-financial-infrastructure)
5. [Operations & Support](#5-operations--support)
6. [Marketing & Branding](#6-marketing--branding)
7. [Team & HR](#7-team--hr)
8. [Timeline & Budget Estimates](#8-timeline--budget-estimates)

---

## 1. Legal & Government Registration (Jordan)

### 1.1 Business Registration Checklist

| Step | Authority | Documents Needed | Estimated Cost | Time |
|------|-----------|------------------|----------------|------|
| ☐ **Reserve Trade Name** | Ministry of Industry & Trade | Application form, ID | ~50 JOD | 1-2 days |
| ☐ **Register Company** | Companies Control Department | Memorandum of Association, Articles | ~300-500 JOD | 3-5 days |
| ☐ **Tax Registration** | Income & Sales Tax Department | Company registration, lease agreement | Free | 1-2 days |
| ☐ **Social Security** | Social Security Corporation | Company docs, employee list | Varies | 1-2 days |
| ☐ **Municipality License** | Greater Amman Municipality (or relevant) | Lease, company docs, photos | ~200-500 JOD/year | 3-7 days |
| ☐ **Chamber of Commerce** | Amman Chamber of Commerce | Company registration | ~100-200 JOD/year | 1 day |

### 1.2 Company Type Options for Jordan

| Type | Arabic | Best For | Min Capital |
|------|--------|----------|-------------|
| **LLC (Limited Liability)** | شركة ذات مسؤولية محدودة | Small-medium startups | 1,000 JOD |
| **Private Shareholding** | شركة مساهمة خاصة | Growth-stage with investors | 50,000 JOD |
| **Sole Proprietorship** | مؤسسة فردية | Single founder testing | None |

**Recommendation:** Start as an **LLC** - it offers liability protection, is investor-friendly, and has reasonable capital requirements.

### 1.3 Industry-Specific Considerations

| Consideration | Status | Notes |
|--------------|--------|-------|
| ☐ E-commerce regulations | Check | Jordan has specific e-commerce laws |
| ☐ Consumer protection compliance | Required | 30-day return policy considerations |
| ☐ Data protection (GDPR-like) | Recommended | Jordan's Data Protection Draft Law |
| ☐ Automotive dealer regulations | Check | May need special permits for dealer features |

### 1.4 Required Government Contacts

```
📍 Companies Control Department (دائرة مراقبة الشركات)
   Address: Amman, Abdali
   Website: www.ccd.gov.jo
   
📍 Income & Sales Tax Department
   Website: www.istd.gov.jo
   
📍 Social Security Corporation
   Website: www.ssc.gov.jo
   
📍 Greater Amman Municipality
   Website: www.ammancity.gov.jo
```

---

## 2. Legal Documents & Policies

### 2.1 Required Legal Documents

| Document | Status | Priority | Notes |
|----------|--------|----------|-------|
| ✅ **Terms of Service** | Complete | 🟢 Done | Template in docs/legal/ |
| ✅ **Privacy Policy** | Complete | 🟢 Done | Template in docs/legal/ |
| ☐ **Cookie Policy** | Missing | 🟡 High | Required for EU users |
| ✅ **Dealer Agreement** | Complete | 🟢 Done | Template in docs/legal/ |
| ☐ **User Code of Conduct** | Missing | 🟡 High | Listing rules, prohibited items |
| ☐ **Refund/Cancellation Policy** | Missing | 🟡 High | For any paid features |
| ☐ **Disclaimer** | Missing | 🟡 High | Price estimates, AI accuracy |
| ☐ **DMCA/Copyright Policy** | Missing | 🟢 Medium | For image uploads |

### 2.2 Terms of Service - Key Sections Needed

```
1. Acceptance of Terms
2. User Accounts & Registration
3. User Responsibilities
4. Prohibited Activities
5. Listing Guidelines
6. Intellectual Property
7. Disclaimers (AI accuracy, price estimates)
8. Limitation of Liability
9. Indemnification
10. Dispute Resolution
11. Governing Law (Jordan)
12. Termination
13. Changes to Terms
14. Contact Information
```

### 2.3 Privacy Policy - Key Sections Needed

```
1. Information We Collect
   - Personal data (name, email, phone)
   - Usage data (analytics, cookies)
   - Images uploaded
2. How We Use Information
3. Information Sharing
   - With dealers
   - With service providers (Google, Cloudinary)
4. Data Retention
5. User Rights
   - Access, correction, deletion
6. Security Measures
7. International Transfers
8. Children's Privacy
9. Changes to Policy
10. Contact for Privacy Concerns
```

### 2.4 Dealer Agreement - Key Terms

```
1. Eligibility Requirements
2. Verification Process
3. Listing Obligations
   - Accuracy of information
   - Photo requirements
   - Price honesty
4. Commission/Fee Structure
5. Performance Standards
6. Prohibited Practices
7. Termination Conditions
8. Dispute Resolution
9. Liability & Insurance
10. Confidentiality
```

---

## 3. Production Readiness (Technical)

### 3.1 Security Checklist

| Item | Status | Priority | Action Needed |
|------|--------|----------|---------------|
| ✅ **SSL Certificate** | Auto (Vercel/Render) | 🟢 Done | HTTPS enabled |
| ☐ **Security Audit** | Missing | 🔴 Critical | Hire penetration tester |
| ☐ **OWASP Top 10 Review** | Partial | 🔴 Critical | Full security review |
| ✅ **Rate Limiting** | Implemented | 🟢 Done | Auth routes protected |
| ✅ **Input Validation** | Implemented | 🟢 Done | Sanitization in place |
| ✅ **SQL Injection Prevention** | Implemented | 🟢 Done | Parameterized queries |
| ✅ **XSS Prevention** | Implemented | 🟢 Done | Input sanitization |
| ✅ **CORS Policy** | Implemented | 🟢 Done | Origin restrictions |
| ✅ **Secrets Management** | Env vars | 🟢 Done | Using environment variables |
| ☐ **Dependency Audit** | Missing | 🟡 High | npm audit, pip-audit |

### 3.2 Infrastructure Checklist

| Item | Status | Priority | Action Needed |
|------|--------|----------|---------------|
| ☐ **Domain Registration** | Missing | 🔴 Critical | Buy intelliwheels.jo or .com |
| ✅ **Production Database** | Render PostgreSQL | 🟢 Done | Already configured |
| ⚠️ **Database Backups** | Check | 🔴 Critical | Enable automatic backups |
| ✅ **CDN for Images** | Cloudinary | 🟢 Done | Already configured |
| ☐ **Error Monitoring** | Missing | 🔴 Critical | Add Sentry or similar |
| ☐ **Uptime Monitoring** | Missing | 🔴 Critical | Add UptimeRobot or Pingdom |
| ☐ **Log Management** | Missing | 🟡 High | Add LogDNA or Papertrail |
| ☐ **CI/CD Pipeline** | Missing | 🟡 High | GitHub Actions for tests |
| ☐ **Staging Environment** | Missing | 🟡 High | Separate test environment |
| ☐ **Load Testing** | Missing | 🟡 High | Test with concurrent users |

### 3.3 Performance Checklist

| Item | Target | Current | Action |
|------|--------|---------|--------|
| ☐ Page Load Time | < 3 seconds | ? | Test with Lighthouse |
| ☐ Time to First Byte | < 600ms | ? | Optimize server response |
| ☐ Largest Contentful Paint | < 2.5s | ? | Image optimization |
| ☐ Core Web Vitals | Pass | ? | Run Google PageSpeed |
| ☐ Mobile Performance | Score > 80 | ? | Test on mobile devices |

### 3.4 Disaster Recovery Plan

```
BACKUP STRATEGY:
├── Database: Daily automated backups (Render)
├── User uploads: Cloudinary (persistent)
├── Code: GitHub repository
└── Configuration: Documented in README

RECOVERY PROCEDURES:
├── Database restore: < 1 hour
├── Full system restore: < 4 hours
└── DNS failover: Configure backup

INCIDENT RESPONSE:
├── Contact list: [Define team contacts]
├── Escalation path: Developer → CTO → CEO
└── Communication: Email users within 24 hours
```

---

## 4. Financial Infrastructure

### 4.1 Banking & Accounting

| Item | Status | Priority | Notes |
|------|--------|----------|-------|
| ☐ **Business Bank Account** | Missing | 🔴 Critical | Arab Bank, Housing Bank recommended |
| ☐ **Accounting Software** | Missing | 🟡 High | QuickBooks, Zoho, or local solution |
| ☐ **Invoice System** | Missing | 🟡 High | For dealer subscriptions |
| ☐ **Tax Accountant** | Missing | 🔴 Critical | Hire for VAT/income tax |
| ☐ **Financial Projections** | Missing | 🟡 High | 3-year forecast for investors |

### 4.2 Payment Integration Options (Jordan)

| Provider | Type | Fees | Integration Effort |
|----------|------|------|-------------------|
| **eFAWATEERcom** | Local bills | Low | Medium |
| **Mamo Pay** | Online payments | 2.5-3% | Easy |
| **PayTabs** | Cards/Wallets | 2.5-3% | Medium |
| **Stripe** | International | 2.9% + 30¢ | Easy (limited in JO) |
| **PayPal** | International | 3.4% + fixed | Easy |
| **Zain Cash / Orange Money** | Mobile wallets | Low | Medium |

**Recommendation:** Start with **Mamo Pay** or **PayTabs** for local payments, add **PayPal** for international.

### 4.3 Revenue Model Implementation

| Revenue Stream | Implementation Status | Priority |
|----------------|----------------------|----------|
| ☐ Dealer Subscriptions | Not implemented | 🔴 High |
| ☐ Featured Listings | Not implemented | 🟡 Medium |
| ☐ Transaction Fees | Not implemented | 🟢 Later |
| ☐ Premium AI Features | Not implemented | 🟢 Later |
| ☐ Advertising | Not implemented | 🟢 Later |

### 4.4 Pricing Strategy (Suggested)

```
DEALER PLANS:
├── Basic (Free)
│   ├── 10 listings
│   ├── Basic analytics
│   └── Standard support
│
├── Pro (50 JOD/month)
│   ├── 50 listings
│   ├── Advanced analytics
│   ├── Priority support
│   └── Verified badge
│
└── Enterprise (Custom)
    ├── Unlimited listings
    ├── API access
    ├── Dedicated support
    └── Custom features

LISTING BOOSTS:
├── Highlight: 5 JOD (7 days)
├── Top Position: 15 JOD (7 days)
└── Homepage Feature: 30 JOD (7 days)
```

---

## 5. Operations & Support

### 5.1 Customer Support System

| Item | Status | Priority | Options |
|------|--------|----------|---------|
| ☐ **Help Desk Software** | Missing | 🔴 Critical | Freshdesk, Zendesk, Crisp |
| ☐ **Support Email** | Missing | 🔴 Critical | support@intelliwheels.com |
| ☐ **Phone Support** | Missing | 🟡 High | Jordan number |
| ☐ **WhatsApp Business** | Missing | 🔴 Critical | Essential for Jordan market |
| ☐ **FAQ/Help Center** | Missing | 🟡 High | Self-service documentation |
| ☐ **Live Chat** | Missing | 🟡 High | Crisp, Intercom, or Tawk.to |

### 5.2 Content Moderation

| Policy | Status | Action Needed |
|--------|--------|---------------|
| ☐ Listing Review Process | Missing | Define approval workflow |
| ☐ Image Moderation | Missing | Use AI or manual review |
| ☐ Spam Detection | Missing | Implement filters |
| ☐ Fake Listing Detection | Missing | Verification process |
| ☐ User Reporting System | Missing | Report button + review queue |
| ☐ Appeal Process | Missing | Define dispute resolution |

### 5.3 Standard Operating Procedures (SOPs)

```
NEEDED SOPs:
├── Dealer Application Review Process
├── Listing Approval Workflow
├── User Complaint Handling
├── Refund Processing (if applicable)
├── Security Incident Response
├── Data Deletion Requests
└── Account Suspension/Ban Process
```

### 5.4 Service Level Agreements (SLAs)

| Metric | Target |
|--------|--------|
| Platform Uptime | 99.5% |
| Support Response (Email) | < 24 hours |
| Support Response (Chat) | < 2 hours |
| Critical Bug Fix | < 4 hours |
| Dealer Application Review | < 48 hours |

---

## 6. Marketing & Branding

### 6.1 Brand Assets Needed

| Asset | Status | Priority |
|-------|--------|----------|
| ☐ **Logo (High-res)** | ✅ Exists | 🟢 Done |
| ☐ **Brand Guidelines** | Missing | 🟡 High |
| ☐ **Color Palette** | ✅ In code | 🟢 Done |
| ☐ **Typography Guide** | Partial | 🟡 High |
| ☐ **Icon Set** | Missing | 🟡 High |
| ☐ **Email Templates** | Missing | 🟡 High |
| ☐ **Social Media Templates** | Missing | 🟡 High |
| ☐ **Business Cards** | Missing | 🟢 Medium |
| ☐ **Presentation Deck** | Missing | 🔴 Critical (for investors) |

### 6.2 Digital Presence

| Platform | Status | Priority | Handle |
|----------|--------|----------|--------|
| ☐ **Website Domain** | Missing | 🔴 Critical | intelliwheels.jo |
| ☐ **Google Business Profile** | Missing | 🔴 Critical | For local SEO |
| ☐ **Facebook Page** | Missing | 🔴 Critical | @intelliwheelsjo |
| ☐ **Instagram** | Missing | 🔴 Critical | @intelliwheelsjo |
| ☐ **LinkedIn Company** | Missing | 🟡 High | For B2B dealers |
| ☐ **Twitter/X** | Missing | 🟢 Medium | @intelliwheels |
| ☐ **TikTok** | Missing | 🟢 Medium | Car content |
| ☐ **YouTube** | Missing | 🟢 Medium | Tutorials, reviews |

### 6.3 Marketing Strategy Essentials

```
LAUNCH STRATEGY:
├── Phase 1: Soft Launch (1-2 months)
│   ├── Invite 10-20 dealers
│   ├── Get feedback
│   └── Fix critical issues
│
├── Phase 2: Beta Launch (2-3 months)
│   ├── Open to 100 dealers
│   ├── PR outreach
│   └── Social media presence
│
└── Phase 3: Public Launch
    ├── Full marketing campaign
    ├── Influencer partnerships
    └── Paid advertising

MARKETING CHANNELS:
├── SEO (Arabic + English keywords)
├── Google Ads (car-related searches)
├── Facebook/Instagram Ads
├── Influencer marketing (car reviewers)
├── Dealer referral program
└── Content marketing (blog, YouTube)
```

### 6.4 SEO Checklist

| Item | Status | Priority |
|------|--------|----------|
| ☐ Meta titles/descriptions | Partial | 🔴 Critical |
| ☐ Arabic keywords research | Missing | 🔴 Critical |
| ☐ Sitemap.xml | Missing | 🔴 Critical |
| ☐ Robots.txt | Missing | 🔴 Critical |
| ☐ Schema markup (Car, Dealer) | Missing | 🟡 High |
| ☐ Blog section | Missing | 🟡 High |
| ☐ Backlink strategy | Missing | 🟡 High |

---

## 7. Team & HR

### 7.1 Essential Roles for Launch

| Role | Status | Priority | Hiring When |
|------|--------|----------|-------------|
| ☐ **Founder/CEO** | ✅ You | 🟢 Done | - |
| ☐ **Full-Stack Developer** | ✅ You | 🟢 Done | - |
| ☐ **Customer Support** | Missing | 🔴 Critical | Before launch |
| ☐ **Content Moderator** | Missing | 🟡 High | At launch |
| ☐ **Marketing/Growth** | Missing | 🟡 High | At launch |
| ☐ **Sales (Dealer Relations)** | Missing | 🟡 High | Before launch |

### 7.2 Outsourcing Options

| Function | Outsource? | Options |
|----------|------------|---------|
| Legal | ✅ Yes | Law firm for contracts |
| Accounting | ✅ Yes | Part-time accountant |
| Design | ✅ Yes | Freelancer for assets |
| Content Writing | ✅ Yes | Freelancer for Arabic/English |
| Security Audit | ✅ Yes | Specialized firm |

### 7.3 Employment Compliance (Jordan)

| Requirement | Notes |
|-------------|-------|
| ☐ Employment contracts | Written contracts required |
| ☐ Social Security registration | Mandatory for all employees |
| ☐ Minimum wage compliance | Currently ~260 JOD/month |
| ☐ Work permits (if hiring non-Jordanians) | Ministry of Labour |
| ☐ Health insurance | Recommended |

---

## 8. Timeline & Budget Estimates

### 8.1 Pre-Launch Timeline

```
MONTH 1: Legal & Setup
├── Week 1-2: Company registration
├── Week 3: Bank account, tax registration
└── Week 4: Legal documents (ToS, Privacy)

MONTH 2: Technical & Operational
├── Week 1-2: Security audit, bug fixes
├── Week 3: Payment integration
└── Week 4: Support system setup

MONTH 3: Marketing & Soft Launch
├── Week 1-2: Brand assets, social media
├── Week 3: Dealer outreach (10-20 dealers)
└── Week 4: Soft launch, gather feedback

MONTH 4-5: Beta & Iteration
├── Expand to 100 dealers
├── Marketing campaigns
└── Feature improvements

MONTH 6: Public Launch
├── Full marketing push
├── PR campaign
└── Scale operations
```

### 8.2 Budget Estimates (JOD)

| Category | One-Time | Monthly | Notes |
|----------|----------|---------|-------|
| **Legal & Registration** | 1,000-2,000 | - | Company setup |
| **Legal Documents** | 500-1,500 | - | Lawyer fees |
| **Domain & Hosting** | 100 | 50-100 | Already have hosting |
| **Security Audit** | 500-2,000 | - | One-time |
| **Marketing (Launch)** | 2,000-5,000 | - | Initial campaign |
| **Marketing (Ongoing)** | - | 500-2,000 | Ads, content |
| **Support Tools** | - | 50-200 | Freshdesk, etc. |
| **Payment Gateway** | 200-500 | % of transactions | Setup fees |
| **Staff (1 support)** | - | 400-600 | Part-time |
| **Accounting** | - | 100-200 | Part-time |
| **Miscellaneous** | 500 | 200 | Buffer |

**Total Estimated:**
- **Launch Cost:** 5,000 - 12,000 JOD
- **Monthly Operating:** 1,500 - 3,500 JOD

### 8.3 Funding Options

| Source | Pros | Cons |
|--------|------|------|
| **Bootstrapping** | Full control | Limited resources |
| **Friends & Family** | Easy terms | Relationship risk |
| **Angel Investors** | Smart money + connections | Equity dilution |
| **Oasis500** | Jordanian accelerator | Competitive, equity |
| **ISSF** | Government support | Process can be slow |
| **Bank Loan** | No equity loss | Collateral required |

---

## 9. Quick Action Items

### Immediate (This Week)
1. ☐ Research company registration requirements
2. ☐ Reserve trade name "IntelliWheels"
3. ☐ Buy domain (intelliwheels.com or .jo)
4. ☐ Create basic Terms of Service
5. ☐ Create Privacy Policy

### Short-Term (This Month)
1. ☐ Register company (LLC)
2. ☐ Open business bank account
3. ☐ Set up support email
4. ☐ Create WhatsApp Business account
5. ☐ Security audit
6. ☐ Set up error monitoring (Sentry)

### Before Launch (Next 2-3 Months)
1. ☐ All legal documents complete
2. ☐ Payment integration working
3. ☐ Support system operational
4. ☐ 10+ verified dealers onboarded
5. ☐ Marketing materials ready
6. ☐ Social media presence established

---

## 10. Resources & Contacts

### Useful Links (Jordan)
- Companies Control Dept: https://www.ccd.gov.jo
- Income Tax: https://www.istd.gov.jo
- Social Security: https://www.ssc.gov.jo
- Oasis500 Accelerator: https://oasis500.com
- Jordan Startups: https://jordanstartups.com

### Recommended Service Providers
- **Legal:** [Research local law firms specializing in tech/startups]
- **Accounting:** [Research local accountants]
- **Security Audit:** [Research cybersecurity firms]

### Templates & Tools
- Terms of Service Generator: termly.io, termsfeed.com
- Privacy Policy Generator: privacypolicies.com
- Business Plan Template: Canva, Slidebean

---

## Summary Checklist

```
LEGAL (Critical)
☐ Company registration
☐ Trade name
☐ Tax registration
☐ Terms of Service
☐ Privacy Policy
☐ Dealer Agreement

TECHNICAL (Critical)
☐ Domain purchase
☐ Security audit
☐ Error monitoring
☐ Database backups
☐ Load testing

FINANCIAL (Critical)
☐ Bank account
☐ Payment gateway
☐ Accounting setup
☐ Pricing finalized

OPERATIONAL (High)
☐ Support system
☐ Content moderation plan
☐ SOPs documented

MARKETING (High)
☐ Brand guidelines
☐ Social media accounts
☐ Launch strategy
☐ Initial dealers onboarded
```

---

*Last Updated: January 2026*
*Document Version: 1.0*
