"""
IntelliWheels Investor Pitch Deck Generator
Generates a professional .pptx presentation
"""

import subprocess
import sys

# Install required package
subprocess.check_call([sys.executable, "-m", "pip", "install", "python-pptx", "-q"])

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
import os

# Brand colors
BLUE_PRIMARY = RGBColor(59, 130, 246)  # #3B82F6
BLUE_DARK = RGBColor(30, 64, 175)      # #1E40AF
ORANGE = RGBColor(249, 115, 22)        # #F97316
WHITE = RGBColor(255, 255, 255)
BLACK = RGBColor(0, 0, 0)
GRAY = RGBColor(107, 114, 128)
LIGHT_GRAY = RGBColor(243, 244, 246)
GREEN = RGBColor(34, 197, 94)
RED = RGBColor(239, 68, 68)

def set_slide_background(slide, color):
    """Set solid background color for a slide"""
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = color

def add_title_slide(prs, title, subtitle):
    """Create a title slide"""
    slide_layout = prs.slide_layouts[6]  # Blank
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, BLUE_PRIMARY)
    
    # Main title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(2.5), Inches(9), Inches(1.5))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = title
    p.font.size = Pt(54)
    p.font.bold = True
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    
    # Subtitle
    sub_box = slide.shapes.add_textbox(Inches(0.5), Inches(4), Inches(9), Inches(1))
    tf = sub_box.text_frame
    p = tf.paragraphs[0]
    p.text = subtitle
    p.font.size = Pt(24)
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    
    # Bottom info
    info_box = slide.shapes.add_textbox(Inches(0.5), Inches(6.5), Inches(9), Inches(0.5))
    tf = info_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Seed Round: 100,000 - 250,000 JOD"
    p.font.size = Pt(18)
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    
    return slide

def add_section_slide(prs, title, content_items, use_icons=True):
    """Create a content slide with bullet points"""
    slide_layout = prs.slide_layouts[6]  # Blank
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, WHITE)
    
    # Blue header bar
    header = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(1.2))
    header.fill.solid()
    header.fill.fore_color.rgb = BLUE_PRIMARY
    header.line.fill.background()
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = title
    p.font.size = Pt(32)
    p.font.bold = True
    p.font.color.rgb = WHITE
    
    # Content
    content_box = slide.shapes.add_textbox(Inches(0.7), Inches(1.5), Inches(8.6), Inches(5))
    tf = content_box.text_frame
    tf.word_wrap = True
    
    for i, item in enumerate(content_items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = item
        p.font.size = Pt(20)
        p.font.color.rgb = BLACK
        p.space_before = Pt(12)
        p.space_after = Pt(6)
    
    return slide

def add_problem_slide(prs):
    """Create the problem slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, WHITE)
    
    # Header
    header = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(1.2))
    header.fill.solid()
    header.fill.fore_color.rgb = BLUE_PRIMARY
    header.line.fill.background()
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "The Problem"
    p.font.size = Pt(32)
    p.font.bold = True
    p.font.color.rgb = WHITE
    
    # Subtitle
    sub_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.4), Inches(9), Inches(0.6))
    tf = sub_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Buying a car in Jordan is broken"
    p.font.size = Pt(28)
    p.font.bold = True
    p.font.color.rgb = BLUE_DARK
    
    # Problem cards
    problems = [
        ("Overwhelming listings", "Hours wasted searching through fragmented platforms"),
        ("No price transparency", "Buyers fear overpaying, sellers undersell"),
        ("Trust issues", "Scams, fraud, and unreliable sellers"),
        ("Language barriers", "Arabic/English confusion in listings"),
        ("No expert help", "Buyers feel lost without guidance"),
    ]
    
    y_pos = 2.2
    for problem, impact in problems:
        # Problem box
        box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.5), Inches(y_pos), Inches(9), Inches(0.8))
        box.fill.solid()
        box.fill.fore_color.rgb = LIGHT_GRAY
        box.line.fill.background()
        
        # Problem text
        prob_box = slide.shapes.add_textbox(Inches(0.7), Inches(y_pos + 0.1), Inches(3), Inches(0.6))
        tf = prob_box.text_frame
        p = tf.paragraphs[0]
        p.text = "✗  " + problem
        p.font.size = Pt(18)
        p.font.bold = True
        p.font.color.rgb = RED
        
        # Impact text
        imp_box = slide.shapes.add_textbox(Inches(4), Inches(y_pos + 0.15), Inches(5.3), Inches(0.6))
        tf = imp_box.text_frame
        p = tf.paragraphs[0]
        p.text = impact
        p.font.size = Pt(16)
        p.font.color.rgb = GRAY
        
        y_pos += 0.95
    
    return slide

def add_solution_slide(prs):
    """Create the solution slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, WHITE)
    
    # Header
    header = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(1.2))
    header.fill.solid()
    header.fill.fore_color.rgb = BLUE_PRIMARY
    header.line.fill.background()
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "The Solution: IntelliWheels"
    p.font.size = Pt(32)
    p.font.bold = True
    p.font.color.rgb = WHITE
    
    # Tagline
    sub_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.4), Inches(9), Inches(0.6))
    tf = sub_box.text_frame
    p = tf.paragraphs[0]
    p.text = "AI Makes Car Buying Easy"
    p.font.size = Pt(24)
    p.font.italic = True
    p.font.color.rgb = BLUE_DARK
    
    # Solution features - 2 columns
    features_left = [
        ("AI Chatbot", "24/7 bilingual expert assistance"),
        ("Vision Analysis", "Know any car from a photo"),
        ("Price Estimator", "ML-based fair pricing"),
    ]
    
    features_right = [
        ("Verified Dealers", "Trust and safety guaranteed"),
        ("Smart Search", "Find cars with natural language"),
        ("Bilingual", "Full Arabic & English support"),
    ]
    
    # Left column
    y_pos = 2.2
    for feature, desc in features_left:
        box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.5), Inches(y_pos), Inches(4.3), Inches(1.1))
        box.fill.solid()
        box.fill.fore_color.rgb = LIGHT_GRAY
        box.line.fill.background()
        
        feat_box = slide.shapes.add_textbox(Inches(0.7), Inches(y_pos + 0.15), Inches(4), Inches(0.4))
        tf = feat_box.text_frame
        p = tf.paragraphs[0]
        p.text = "✓  " + feature
        p.font.size = Pt(18)
        p.font.bold = True
        p.font.color.rgb = GREEN
        
        desc_box = slide.shapes.add_textbox(Inches(0.7), Inches(y_pos + 0.55), Inches(4), Inches(0.5))
        tf = desc_box.text_frame
        p = tf.paragraphs[0]
        p.text = desc
        p.font.size = Pt(14)
        p.font.color.rgb = GRAY
        
        y_pos += 1.3
    
    # Right column
    y_pos = 2.2
    for feature, desc in features_right:
        box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(5.2), Inches(y_pos), Inches(4.3), Inches(1.1))
        box.fill.solid()
        box.fill.fore_color.rgb = LIGHT_GRAY
        box.line.fill.background()
        
        feat_box = slide.shapes.add_textbox(Inches(5.4), Inches(y_pos + 0.15), Inches(4), Inches(0.4))
        tf = feat_box.text_frame
        p = tf.paragraphs[0]
        p.text = "✓  " + feature
        p.font.size = Pt(18)
        p.font.bold = True
        p.font.color.rgb = GREEN
        
        desc_box = slide.shapes.add_textbox(Inches(5.4), Inches(y_pos + 0.55), Inches(4), Inches(0.5))
        tf = desc_box.text_frame
        p = tf.paragraphs[0]
        p.text = desc
        p.font.size = Pt(14)
        p.font.color.rgb = GRAY
        
        y_pos += 1.3
    
    # Bottom tagline
    tag_box = slide.shapes.add_textbox(Inches(0.5), Inches(6.3), Inches(9), Inches(0.5))
    tf = tag_box.text_frame
    p = tf.paragraphs[0]
    p.text = '"The only automotive platform in Jordan with AI capabilities"'
    p.font.size = Pt(16)
    p.font.italic = True
    p.font.color.rgb = BLUE_PRIMARY
    p.alignment = PP_ALIGN.CENTER
    
    return slide

def add_market_slide(prs):
    """Create market opportunity slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, WHITE)
    
    # Header
    header = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(1.2))
    header.fill.solid()
    header.fill.fore_color.rgb = BLUE_PRIMARY
    header.line.fill.background()
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Market Opportunity"
    p.font.size = Pt(32)
    p.font.bold = True
    p.font.color.rgb = WHITE
    
    # Market size boxes
    markets = [
        ("2B+ JOD", "Total Automotive\nMarket (Annual)"),
        ("500M+ JOD", "Used Car\nMarket"),
        ("100M+ JOD", "Digital\nOpportunity"),
        ("20M JOD", "Our Target\n(Year 3)"),
    ]
    
    x_pos = 0.3
    for value, label in markets:
        box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x_pos), Inches(1.5), Inches(2.2), Inches(1.8))
        box.fill.solid()
        box.fill.fore_color.rgb = BLUE_PRIMARY
        box.line.fill.background()
        
        val_box = slide.shapes.add_textbox(Inches(x_pos), Inches(1.7), Inches(2.2), Inches(0.7))
        tf = val_box.text_frame
        p = tf.paragraphs[0]
        p.text = value
        p.font.size = Pt(24)
        p.font.bold = True
        p.font.color.rgb = WHITE
        p.alignment = PP_ALIGN.CENTER
        
        lab_box = slide.shapes.add_textbox(Inches(x_pos), Inches(2.4), Inches(2.2), Inches(0.8))
        tf = lab_box.text_frame
        p = tf.paragraphs[0]
        p.text = label
        p.font.size = Pt(12)
        p.font.color.rgb = WHITE
        p.alignment = PP_ALIGN.CENTER
        
        x_pos += 2.45
    
    # Why Now section
    why_box = slide.shapes.add_textbox(Inches(0.5), Inches(3.6), Inches(9), Inches(0.5))
    tf = why_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Why Now?"
    p.font.size = Pt(24)
    p.font.bold = True
    p.font.color.rgb = BLUE_DARK
    
    reasons = [
        "95% smartphone penetration in Jordan",
        "Post-COVID digital adoption acceleration",
        "No AI-powered competitor in the market",
        "Young, tech-savvy population (65% under 35)",
        "Growing trust in e-commerce platforms",
    ]
    
    y_pos = 4.2
    for reason in reasons:
        r_box = slide.shapes.add_textbox(Inches(0.7), Inches(y_pos), Inches(9), Inches(0.4))
        tf = r_box.text_frame
        p = tf.paragraphs[0]
        p.text = "→  " + reason
        p.font.size = Pt(16)
        p.font.color.rgb = BLACK
        y_pos += 0.45
    
    return slide

def add_business_model_slide(prs):
    """Create business model slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, WHITE)
    
    # Header
    header = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(1.2))
    header.fill.solid()
    header.fill.fore_color.rgb = BLUE_PRIMARY
    header.line.fill.background()
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Business Model"
    p.font.size = Pt(32)
    p.font.bold = True
    p.font.color.rgb = WHITE
    
    # Revenue streams
    streams = [
        ("Dealer Subscriptions", "50-200 JOD/month", "60%"),
        ("Featured Listings", "5-30 JOD per listing", "25%"),
        ("Premium AI Features", "5-20 JOD/month", "10%"),
        ("Lead Generation", "Per qualified lead", "5%"),
    ]
    
    # Table header
    headers_text = ["Revenue Stream", "Pricing", "% of Revenue"]
    x_positions = [0.5, 4, 7]
    
    for i, header_text in enumerate(headers_text):
        h_box = slide.shapes.add_textbox(Inches(x_positions[i]), Inches(1.5), Inches(3), Inches(0.4))
        tf = h_box.text_frame
        p = tf.paragraphs[0]
        p.text = header_text
        p.font.size = Pt(16)
        p.font.bold = True
        p.font.color.rgb = BLUE_DARK
    
    # Table rows
    y_pos = 2.0
    for stream, price, pct in streams:
        row_bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.4), Inches(y_pos), Inches(9.2), Inches(0.5))
        row_bg.fill.solid()
        row_bg.fill.fore_color.rgb = LIGHT_GRAY
        row_bg.line.fill.background()
        
        s_box = slide.shapes.add_textbox(Inches(0.5), Inches(y_pos + 0.1), Inches(3.5), Inches(0.4))
        tf = s_box.text_frame
        p = tf.paragraphs[0]
        p.text = stream
        p.font.size = Pt(14)
        p.font.color.rgb = BLACK
        
        p_box = slide.shapes.add_textbox(Inches(4), Inches(y_pos + 0.1), Inches(3), Inches(0.4))
        tf = p_box.text_frame
        p = tf.paragraphs[0]
        p.text = price
        p.font.size = Pt(14)
        p.font.color.rgb = BLACK
        
        pct_box = slide.shapes.add_textbox(Inches(7), Inches(y_pos + 0.1), Inches(2), Inches(0.4))
        tf = pct_box.text_frame
        p = tf.paragraphs[0]
        p.text = pct
        p.font.size = Pt(14)
        p.font.bold = True
        p.font.color.rgb = BLUE_PRIMARY
        
        y_pos += 0.6
    
    # Unit Economics
    ue_title = slide.shapes.add_textbox(Inches(0.5), Inches(4.3), Inches(9), Inches(0.5))
    tf = ue_title.text_frame
    p = tf.paragraphs[0]
    p.text = "Unit Economics"
    p.font.size = Pt(20)
    p.font.bold = True
    p.font.color.rgb = BLUE_DARK
    
    metrics = [
        ("CAC (Dealer)", "50-100 JOD"),
        ("LTV (Dealer)", "1,000+ JOD"),
        ("LTV:CAC Ratio", "10:1+"),
    ]
    
    x_pos = 0.5
    for metric, value in metrics:
        m_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x_pos), Inches(4.8), Inches(2.8), Inches(1.2))
        m_box.fill.solid()
        m_box.fill.fore_color.rgb = BLUE_PRIMARY
        m_box.line.fill.background()
        
        v_box = slide.shapes.add_textbox(Inches(x_pos), Inches(4.95), Inches(2.8), Inches(0.5))
        tf = v_box.text_frame
        p = tf.paragraphs[0]
        p.text = value
        p.font.size = Pt(22)
        p.font.bold = True
        p.font.color.rgb = WHITE
        p.alignment = PP_ALIGN.CENTER
        
        l_box = slide.shapes.add_textbox(Inches(x_pos), Inches(5.45), Inches(2.8), Inches(0.4))
        tf = l_box.text_frame
        p = tf.paragraphs[0]
        p.text = metric
        p.font.size = Pt(12)
        p.font.color.rgb = WHITE
        p.alignment = PP_ALIGN.CENTER
        
        x_pos += 3.1
    
    return slide

def add_traction_slide(prs):
    """Create traction slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, WHITE)
    
    # Header
    header = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(1.2))
    header.fill.solid()
    header.fill.fore_color.rgb = BLUE_PRIMARY
    header.line.fill.background()
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Traction & Progress"
    p.font.size = Pt(32)
    p.font.bold = True
    p.font.color.rgb = WHITE
    
    # Progress items
    completed = [
        "Full MVP built and deployed to production",
        "AI Chatbot working (Arabic/English) - Gemini 2.5",
        "Vision analysis feature complete",
        "Price estimation ML model trained",
        "Semantic search implemented",
        "Car database with filters ready",
        "Dealer management system complete",
        "User authentication (Google OAuth)",
        "Messaging system for buyer-seller",
        "Reviews and ratings system",
        "Legal document templates ready",
    ]
    
    in_progress = [
        "Dealer outreach starting",
        "Payment integration planning",
        "Marketing preparation",
    ]
    
    # Completed section
    comp_title = slide.shapes.add_textbox(Inches(0.5), Inches(1.4), Inches(4), Inches(0.4))
    tf = comp_title.text_frame
    p = tf.paragraphs[0]
    p.text = "✓ Completed"
    p.font.size = Pt(20)
    p.font.bold = True
    p.font.color.rgb = GREEN
    
    y_pos = 1.9
    for item in completed:
        i_box = slide.shapes.add_textbox(Inches(0.7), Inches(y_pos), Inches(4.5), Inches(0.35))
        tf = i_box.text_frame
        p = tf.paragraphs[0]
        p.text = "• " + item
        p.font.size = Pt(14)
        p.font.color.rgb = BLACK
        y_pos += 0.4
    
    # In Progress section
    prog_title = slide.shapes.add_textbox(Inches(5.5), Inches(1.4), Inches(4), Inches(0.4))
    tf = prog_title.text_frame
    p = tf.paragraphs[0]
    p.text = "⏳ In Progress"
    p.font.size = Pt(20)
    p.font.bold = True
    p.font.color.rgb = ORANGE
    
    y_pos = 1.9
    for item in in_progress:
        i_box = slide.shapes.add_textbox(Inches(5.7), Inches(y_pos), Inches(4), Inches(0.35))
        tf = i_box.text_frame
        p = tf.paragraphs[0]
        p.text = "• " + item
        p.font.size = Pt(14)
        p.font.color.rgb = BLACK
        y_pos += 0.4
    
    # Ready to launch box
    ready_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(2.5), Inches(5.8), Inches(5), Inches(0.8))
    ready_box.fill.solid()
    ready_box.fill.fore_color.rgb = BLUE_PRIMARY
    ready_box.line.fill.background()
    
    r_text = slide.shapes.add_textbox(Inches(2.5), Inches(5.95), Inches(5), Inches(0.5))
    tf = r_text.text_frame
    p = tf.paragraphs[0]
    p.text = "Ready to launch within 60 days"
    p.font.size = Pt(20)
    p.font.bold = True
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    
    return slide

def add_competition_slide(prs):
    """Create competition slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, WHITE)
    
    # Header
    header = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(1.2))
    header.fill.solid()
    header.fill.fore_color.rgb = BLUE_PRIMARY
    header.line.fill.background()
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Competitive Advantage"
    p.font.size = Pt(32)
    p.font.bold = True
    p.font.color.rgb = WHITE
    
    # Comparison table header
    cols = ["Feature", "IntelliWheels", "OpenSooq", "FB Marketplace"]
    col_widths = [2.2, 2.2, 2.2, 2.2]
    x_pos = 0.5
    
    for i, col in enumerate(cols):
        h_box = slide.shapes.add_textbox(Inches(x_pos), Inches(1.5), Inches(col_widths[i]), Inches(0.4))
        tf = h_box.text_frame
        p = tf.paragraphs[0]
        p.text = col
        p.font.size = Pt(14)
        p.font.bold = True
        p.font.color.rgb = BLUE_DARK
        p.alignment = PP_ALIGN.CENTER
        x_pos += col_widths[i] + 0.1
    
    # Table rows
    features = [
        ("AI Chatbot", "✓", "✗", "✗"),
        ("Vision Analysis", "✓", "✗", "✗"),
        ("Price Estimator", "✓", "✗", "✗"),
        ("Automotive Focus", "✓", "✗", "✗"),
        ("Verified Dealers", "✓", "Partial", "✗"),
        ("Modern UX", "✓", "✗", "✓"),
        ("Bilingual RTL", "✓", "✓", "Partial"),
    ]
    
    y_pos = 2.0
    for row in features:
        x_pos = 0.5
        row_bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.4), Inches(y_pos), Inches(9.2), Inches(0.45))
        row_bg.fill.solid()
        row_bg.fill.fore_color.rgb = LIGHT_GRAY
        row_bg.line.fill.background()
        
        for i, cell in enumerate(row):
            c_box = slide.shapes.add_textbox(Inches(x_pos), Inches(y_pos + 0.08), Inches(col_widths[i]), Inches(0.35))
            tf = c_box.text_frame
            p = tf.paragraphs[0]
            p.text = cell
            p.font.size = Pt(13)
            if cell == "✓":
                p.font.color.rgb = GREEN
                p.font.bold = True
            elif cell == "✗":
                p.font.color.rgb = RED
            else:
                p.font.color.rgb = BLACK
            p.alignment = PP_ALIGN.CENTER if i > 0 else PP_ALIGN.LEFT
            x_pos += col_widths[i] + 0.1
        y_pos += 0.5
    
    # Advantage text
    adv_box = slide.shapes.add_textbox(Inches(0.5), Inches(5.8), Inches(9), Inches(0.5))
    tf = adv_box.text_frame
    p = tf.paragraphs[0]
    p.text = '"6-12 month head start in AI features - first mover advantage"'
    p.font.size = Pt(18)
    p.font.italic = True
    p.font.color.rgb = BLUE_PRIMARY
    p.alignment = PP_ALIGN.CENTER
    
    return slide

def add_financials_slide(prs):
    """Create financial projections slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, WHITE)
    
    # Header
    header = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(1.2))
    header.fill.solid()
    header.fill.fore_color.rgb = BLUE_PRIMARY
    header.line.fill.background()
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Financial Projections"
    p.font.size = Pt(32)
    p.font.bold = True
    p.font.color.rgb = WHITE
    
    # Table header
    cols = ["Metric", "Year 1", "Year 2", "Year 3"]
    col_widths = [2.5, 2, 2, 2]
    x_pos = 0.7
    
    for i, col in enumerate(cols):
        h_box = slide.shapes.add_textbox(Inches(x_pos), Inches(1.5), Inches(col_widths[i]), Inches(0.4))
        tf = h_box.text_frame
        p = tf.paragraphs[0]
        p.text = col
        p.font.size = Pt(16)
        p.font.bold = True
        p.font.color.rgb = BLUE_DARK
        p.alignment = PP_ALIGN.CENTER if i > 0 else PP_ALIGN.LEFT
        x_pos += col_widths[i] + 0.2
    
    # Data rows
    data = [
        ("Dealers", "100", "500", "1,500"),
        ("Listings", "2,000", "15,000", "50,000"),
        ("Revenue (JOD)", "50,000", "350,000", "1,200,000"),
        ("Expenses (JOD)", "80,000", "300,000", "800,000"),
        ("Net (JOD)", "-30,000", "+50,000", "+400,000"),
    ]
    
    y_pos = 2.0
    for row in data:
        x_pos = 0.7
        row_bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.5), Inches(y_pos), Inches(8.5), Inches(0.55))
        row_bg.fill.solid()
        row_bg.fill.fore_color.rgb = LIGHT_GRAY
        row_bg.line.fill.background()
        
        for i, cell in enumerate(row):
            c_box = slide.shapes.add_textbox(Inches(x_pos), Inches(y_pos + 0.1), Inches(col_widths[i]), Inches(0.4))
            tf = c_box.text_frame
            p = tf.paragraphs[0]
            p.text = cell
            p.font.size = Pt(15)
            if row[0] == "Net (JOD)":
                if cell.startswith("+"):
                    p.font.color.rgb = GREEN
                    p.font.bold = True
                elif cell.startswith("-"):
                    p.font.color.rgb = RED
                    p.font.bold = True
                else:
                    p.font.color.rgb = BLACK
            else:
                p.font.color.rgb = BLACK
            p.alignment = PP_ALIGN.CENTER if i > 0 else PP_ALIGN.LEFT
            x_pos += col_widths[i] + 0.2
        y_pos += 0.65
    
    # Growth indicators
    growth_box = slide.shapes.add_textbox(Inches(0.5), Inches(5.5), Inches(9), Inches(1))
    tf = growth_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Path to Profitability: Break-even by Year 2, profitable by Year 3"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = GREEN
    p.alignment = PP_ALIGN.CENTER
    
    return slide

def add_ask_slide(prs):
    """Create the ask slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, BLUE_PRIMARY)
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(9), Inches(1))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "The Ask"
    p.font.size = Pt(40)
    p.font.bold = True
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    
    # Amount box
    amt_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(2), Inches(1.8), Inches(6), Inches(1.2))
    amt_box.fill.solid()
    amt_box.fill.fore_color.rgb = WHITE
    amt_box.line.fill.background()
    
    amt_text = slide.shapes.add_textbox(Inches(2), Inches(2.05), Inches(6), Inches(0.9))
    tf = amt_text.text_frame
    p = tf.paragraphs[0]
    p.text = "Seed Round: 100,000 - 250,000 JOD"
    p.font.size = Pt(28)
    p.font.bold = True
    p.font.color.rgb = BLUE_PRIMARY
    p.alignment = PP_ALIGN.CENTER
    
    # Use of funds
    funds = [
        ("Team & Salaries", "40%"),
        ("Marketing & Growth", "30%"),
        ("Product Development", "20%"),
        ("Operations & Legal", "10%"),
    ]
    
    funds_title = slide.shapes.add_textbox(Inches(0.5), Inches(3.3), Inches(9), Inches(0.5))
    tf = funds_title.text_frame
    p = tf.paragraphs[0]
    p.text = "Use of Funds"
    p.font.size = Pt(22)
    p.font.bold = True
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    
    y_pos = 3.9
    for use, pct in funds:
        f_box = slide.shapes.add_textbox(Inches(2.5), Inches(y_pos), Inches(3.5), Inches(0.4))
        tf = f_box.text_frame
        p = tf.paragraphs[0]
        p.text = use
        p.font.size = Pt(16)
        p.font.color.rgb = WHITE
        
        p_box = slide.shapes.add_textbox(Inches(6), Inches(y_pos), Inches(1.5), Inches(0.4))
        tf = p_box.text_frame
        p = tf.paragraphs[0]
        p.text = pct
        p.font.size = Pt(16)
        p.font.bold = True
        p.font.color.rgb = WHITE
        
        y_pos += 0.45
    
    # Milestones
    mile_title = slide.shapes.add_textbox(Inches(0.5), Inches(6), Inches(9), Inches(0.4))
    tf = mile_title.text_frame
    p = tf.paragraphs[0]
    p.text = "Milestones: 100 dealers (6mo) → 500 dealers (12mo) → Profitable (18mo)"
    p.font.size = Pt(14)
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    
    return slide

def add_why_us_slide(prs):
    """Create why us slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, WHITE)
    
    # Header
    header = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(10), Inches(1.2))
    header.fill.solid()
    header.fill.fore_color.rgb = BLUE_PRIMARY
    header.line.fill.background()
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(9), Inches(0.7))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Why Us, Why Now"
    p.font.size = Pt(32)
    p.font.bold = True
    p.font.color.rgb = WHITE
    
    # Reasons
    reasons = [
        ("First Mover", "First AI-powered automotive platform in Jordan"),
        ("Built", "MVP is ready and functional - not just an idea"),
        ("Market", "500M+ JOD market that's underserved digitally"),
        ("Team", "Technical founder who ships product"),
        ("Timing", "Digital transformation moment post-COVID"),
    ]
    
    y_pos = 1.6
    for title, desc in reasons:
        # Checkmark box
        check_box = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(0.5), Inches(y_pos + 0.1), Inches(0.5), Inches(0.5))
        check_box.fill.solid()
        check_box.fill.fore_color.rgb = GREEN
        check_box.line.fill.background()
        
        c_text = slide.shapes.add_textbox(Inches(0.5), Inches(y_pos + 0.15), Inches(0.5), Inches(0.5))
        tf = c_text.text_frame
        p = tf.paragraphs[0]
        p.text = "✓"
        p.font.size = Pt(20)
        p.font.bold = True
        p.font.color.rgb = WHITE
        p.alignment = PP_ALIGN.CENTER
        
        # Title
        t_box = slide.shapes.add_textbox(Inches(1.2), Inches(y_pos), Inches(8), Inches(0.4))
        tf = t_box.text_frame
        p = tf.paragraphs[0]
        p.text = title
        p.font.size = Pt(22)
        p.font.bold = True
        p.font.color.rgb = BLUE_DARK
        
        # Description
        d_box = slide.shapes.add_textbox(Inches(1.2), Inches(y_pos + 0.45), Inches(8), Inches(0.4))
        tf = d_box.text_frame
        p = tf.paragraphs[0]
        p.text = desc
        p.font.size = Pt(16)
        p.font.color.rgb = GRAY
        
        y_pos += 1.0
    
    # CTA
    cta_box = slide.shapes.add_textbox(Inches(0.5), Inches(6.3), Inches(9), Inches(0.5))
    tf = cta_box.text_frame
    p = tf.paragraphs[0]
    p.text = '"Join us in transforming car buying in Jordan"'
    p.font.size = Pt(20)
    p.font.italic = True
    p.font.color.rgb = BLUE_PRIMARY
    p.alignment = PP_ALIGN.CENTER
    
    return slide

def add_contact_slide(prs):
    """Create contact slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide, BLUE_PRIMARY)
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.5), Inches(9), Inches(1))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    p.text = "IntelliWheels"
    p.font.size = Pt(54)
    p.font.bold = True
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    
    # Tagline
    tag_box = slide.shapes.add_textbox(Inches(0.5), Inches(2.5), Inches(9), Inches(0.6))
    tf = tag_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Your AI Car Expert"
    p.font.size = Pt(24)
    p.font.italic = True
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    
    # Contact info box
    contact_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(2.5), Inches(3.5), Inches(5), Inches(2))
    contact_box.fill.solid()
    contact_box.fill.fore_color.rgb = WHITE
    contact_box.line.fill.background()
    
    # Contact details
    contact_text = slide.shapes.add_textbox(Inches(2.5), Inches(3.7), Inches(5), Inches(1.8))
    tf = contact_text.text_frame
    
    p = tf.paragraphs[0]
    p.text = "[Your Name]"
    p.font.size = Pt(20)
    p.font.bold = True
    p.font.color.rgb = BLUE_DARK
    p.alignment = PP_ALIGN.CENTER
    
    p = tf.add_paragraph()
    p.text = "Founder & CEO"
    p.font.size = Pt(14)
    p.font.color.rgb = GRAY
    p.alignment = PP_ALIGN.CENTER
    p.space_after = Pt(12)
    
    p = tf.add_paragraph()
    p.text = "📧  your@email.com"
    p.font.size = Pt(14)
    p.font.color.rgb = BLACK
    p.alignment = PP_ALIGN.CENTER
    
    p = tf.add_paragraph()
    p.text = "📱  +962 XX XXX XXXX"
    p.font.size = Pt(14)
    p.font.color.rgb = BLACK
    p.alignment = PP_ALIGN.CENTER
    
    # Questions
    q_box = slide.shapes.add_textbox(Inches(0.5), Inches(6), Inches(9), Inches(0.5))
    tf = q_box.text_frame
    p = tf.paragraphs[0]
    p.text = "Questions?"
    p.font.size = Pt(28)
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    
    return slide

def create_presentation():
    """Create the full pitch deck"""
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)
    
    print("Creating pitch deck slides...")
    
    # Slide 1: Title
    print("  • Title slide")
    add_title_slide(prs, "IntelliWheels", "AI-Powered Automotive Marketplace")
    
    # Slide 2: Problem
    print("  • Problem slide")
    add_problem_slide(prs)
    
    # Slide 3: Solution
    print("  • Solution slide")
    add_solution_slide(prs)
    
    # Slide 4: Market
    print("  • Market opportunity slide")
    add_market_slide(prs)
    
    # Slide 5: Business Model
    print("  • Business model slide")
    add_business_model_slide(prs)
    
    # Slide 6: Traction
    print("  • Traction slide")
    add_traction_slide(prs)
    
    # Slide 7: Competition
    print("  • Competition slide")
    add_competition_slide(prs)
    
    # Slide 8: Financials
    print("  • Financial projections slide")
    add_financials_slide(prs)
    
    # Slide 9: The Ask
    print("  • The Ask slide")
    add_ask_slide(prs)
    
    # Slide 10: Why Us
    print("  • Why Us slide")
    add_why_us_slide(prs)
    
    # Slide 11: Contact
    print("  • Contact slide")
    add_contact_slide(prs)
    
    # Save
    output_path = os.path.join(os.path.dirname(__file__), "IntelliWheels_Pitch_Deck.pptx")
    prs.save(output_path)
    
    print(f"\n✅ Pitch deck saved to: {output_path}")
    print(f"   Total slides: 11")
    print("\n📝 Remember to customize:")
    print("   - Add your name and contact info (Slide 11)")
    print("   - Add your logo image")
    print("   - Add product screenshots")
    print("   - Review and adjust financial projections")
    
    return output_path

if __name__ == "__main__":
    create_presentation()
