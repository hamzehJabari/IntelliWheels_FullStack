# IntelliWheels Pitch Deck Outline

**Investor Presentation Guide**

---

## Slide-by-Slide Guide

Use this outline to create your pitch deck in PowerPoint, Google Slides, or Canva.

---

## Slide 1: Title

**IntelliWheels**
*AI-Powered Automotive Marketplace*

- Logo (large, centered)
- Tagline: "Your AI Car Expert"
- Your Name, Founder
- Date
- "Seed Round: 100K-250K JOD"

---

## Slide 2: The Problem

**Buying a car in Jordan is broken**

| Pain Point | Impact |
|------------|--------|
| 😤 Overwhelming listings | Hours wasted searching |
| 🤔 No price transparency | Fear of overpaying |
| 😰 Trust issues | Scams and fraud |
| 🌐 Language barriers | Arabic/English confusion |
| ❓ No expert help | Buyers feel lost |

*Visual: Show frustrated person with question marks*

---

## Slide 3: The Solution

**IntelliWheels: AI Makes Car Buying Easy**

| Feature | Benefit |
|---------|---------|
| 🤖 AI Chatbot | 24/7 expert assistance |
| 📸 Vision Analysis | Know any car from a photo |
| 💰 Price Estimator | Fair pricing confidence |
| ✅ Verified Dealers | Trust and safety |
| 🔍 Smart Search | Find cars naturally |

*Visual: Clean app screenshots showing features*

---

## Slide 4: Demo

**See It In Action**

- 2-3 screenshots or short video
- Show: Chatbot conversation
- Show: Vision feature analyzing a car
- Show: Price estimation result

*"The only automotive platform in Jordan with AI capabilities"*

---

## Slide 5: Market Opportunity

**Jordan's Car Market is Huge**

```
Total Market: 2B+ JOD/year
Used Cars: 500M+ JOD/year
Digital Opportunity: 100M+ JOD
Our Target (Year 3): 20M JOD GMV
```

**Why Now?**
- 95% smartphone penetration
- Post-COVID digital shift
- No AI-powered competitor
- Young, tech-savvy population

---

## Slide 6: Business Model

**Multiple Revenue Streams**

| Stream | Price | Target |
|--------|-------|--------|
| Dealer Subscriptions | 50-200 JOD/mo | 1,500 dealers |
| Featured Listings | 5-30 JOD | 10% of listings |
| Premium AI | 5-20 JOD/mo | 5,000 users |

**Unit Economics:**
- CAC (Dealer): 50-100 JOD
- LTV (Dealer): 1,000+ JOD
- LTV:CAC Ratio: 10:1+

---

## Slide 7: Traction

**Progress to Date**

- ✅ Full MVP built and functional
- ✅ AI features working (chatbot, vision, price)
- ✅ Bilingual support (Arabic/English)
- ✅ 300+ car database ready
- ✅ Dealer system complete
- ⏳ Legal registration: In progress
- ⏳ First dealers: Outreach starting

*"Ready to launch within 60 days"*

---

## Slide 8: Competition

**We're Different**

| Feature | IntelliWheels | OpenSooq | FB Marketplace |
|---------|---------------|----------|----------------|
| AI Chatbot | ✅ | ❌ | ❌ |
| Vision Analysis | ✅ | ❌ | ❌ |
| Price Estimator | ✅ | ❌ | ❌ |
| Automotive Focus | ✅ | ❌ | ❌ |
| Verified Dealers | ✅ | Partial | ❌ |
| Modern UX | ✅ | ❌ | ✅ |

*"6-12 month head start in AI features"*

---

## Slide 9: Go-to-Market

**Launch Strategy**

```
Month 1-2: Soft Launch
├── 20-50 dealers
├── Feedback & iteration

Month 3-4: Beta Launch  
├── 100 dealers
├── Digital marketing begins

Month 5-6: Public Launch
├── Full marketing push
├── 200+ dealers

Month 12: Scale
├── 500 dealers
├── Path to profitability
```

---

## Slide 10: Financial Projections

**Path to Profitability**

| Metric | Year 1 | Year 2 | Year 3 |
|--------|--------|--------|--------|
| Dealers | 100 | 500 | 1,500 |
| Revenue | 50K | 350K | 1.2M |
| Net | -30K | +50K | +400K |

*Chart: Show hockey stick growth*

---

## Slide 11: Team

**Built by Passionate Founders**

**[Your Name] - Founder & CEO**
- Background: [Your background]
- Skills: Full-stack development, AI/ML
- Education: [Your education]

**Advisors / Future Hires:**
- [List any advisors]
- Hiring: CTO, Marketing, Sales

*"Technical founder with vision"*

---

## Slide 12: The Ask

**Seed Round: 100,000 - 250,000 JOD**

| Use of Funds | % |
|--------------|---|
| Team | 40% |
| Marketing | 30% |
| Product | 20% |
| Operations | 10% |

**Milestones:**
- 6 months: 100 paying dealers
- 12 months: 500 dealers, break-even path
- 18 months: Profitable or Series A

---

## Slide 13: Why Us, Why Now

**The Opportunity**

✅ **First-mover** in AI automotive in Jordan  
✅ **Built** - MVP is ready, not just an idea  
✅ **Market** - 500M+ JOD market, underserved  
✅ **Team** - Technical founder who ships  
✅ **Timing** - Digital transformation moment  

*"Join us in transforming car buying in Jordan"*

---

## Slide 14: Contact

**Let's Talk**

**[Your Name]**  
Founder & CEO

📧 [your@email.com]  
📱 [your phone]  
🌐 intelliwheels.com

[Logo]

*"Questions?"*

---

## Appendix Slides (Have Ready)

### A1: Technical Architecture
- System diagram
- Tech stack overview
- Security measures

### A2: Detailed Financials
- Monthly projections
- Expense breakdown
- Scenario analysis

### A3: Market Research
- Survey data
- Competitor deep-dive
- User personas

### A4: Product Roadmap
- Feature timeline
- Mobile app plans
- Future AI features

### A5: Risk Analysis
- Key risks
- Mitigation strategies

---

## Pitch Deck Tips

### Design Guidelines
- **Slides:** 10-15 maximum for main deck
- **Font:** Clean, readable (Helvetica, Inter)
- **Colors:** Match brand (Blue #3B82F6)
- **Images:** High quality, relevant
- **Text:** Minimal - speak, don't read

### Timing
- **Target:** 10-15 minutes
- **Per slide:** 1-2 minutes max
- **Leave time:** For questions

### What Investors Want
1. Large market opportunity
2. Strong team
3. Working product (you have this!)
4. Clear business model
5. Defensible advantage
6. Realistic financials
7. Clear use of funds

### Common Questions to Prepare

1. "How do you acquire dealers?"
2. "What if OpenSooq copies you?"
3. "Why will users switch from Facebook?"
4. "What's your AI cost per query?"
5. "How accurate is price estimation?"
6. "What's your runway?"
7. "What's the exit strategy?"

---

## Tools to Create Pitch Deck

| Tool | Best For | Cost |
|------|----------|------|
| **Canva** | Design templates | Free-$15/mo |
| **Google Slides** | Collaboration | Free |
| **PowerPoint** | Traditional | $10/mo |
| **Pitch** | Modern startups | Free-$8/mo |
| **Beautiful.ai** | Auto-design | $12/mo |
| **Slidebean** | Startup-focused | $8/mo |

---

*Last Updated: January 2026*
